# Google Play listing text (copy and paste)

**App name (max 30):** PDF Magic: Merge & Edit PDFs   (28)

**Short description (max 80):** Merge, split, compress and edit PDFs offline. No ads. Files stay on your phone.   (79)

**Full description (max 4000):**

PDF Magic is a fast, private PDF toolbox. Everything works offline: your files never leave your phone.

WHAT YOU CAN DO
- Merge PDFs and photos into one PDF, in date order or your own order
- Turn photos into a PDF at original quality
- Compress PDFs and photos: choose High, Medium, Low, Smallest, or set a target size in MB
- Split a PDF: every page, every few pages, or by page ranges
- Edit pages: rotate, delete, copy, move, replace, insert blank pages
- Add text, pictures, shapes, arrows, highlights, pen drawings, notes and stamps
- Read PDFs: search, zoom, thumbnails, dark mode, share and print
- Create PDFs from text, web pages (saved HTML), Word documents, or a camera scan
- Open PDFs from other apps with "Open with" and "Share"

PRIVATE BY DESIGN
- No internet permission. No ads. No tracking. No account.
- Optional lock with your phone's fingerprint, face or PIN
- Optional "hide in recent apps and block screenshots"

Convert. Create. Simplify.

---

**Category:** Productivity (or Tools)
**Contact email / website:** your email
**Privacy policy URL:** the address of your privacy page (see README, Part D)

## Data safety form (Play Console > App content)
- Does your app collect or share any of the required user data types? **No**
- Is all of the user data collected by your app encrypted in transit? (not shown when nothing is collected)
- Data deletion: not applicable (no data collected)

## Other App content answers
- Ads: **No**
- App access: **All functionality available without special access**
- Content rating: answer the questionnaire honestly (no violence, no user-generated content shared online, no location) and you should get **Everyone**
- Target audience: **18 and over** is the simplest choice for a tools app
- Government / news / health / financial app: **No**

## Graphics
- App icon 512x512: `store/play-icon-512.png`
- Feature graphic 1024x500: `store/feature-graphic-1024x500.png`
- Phone screenshots: take at least 2 (ideally 4 to 8) on your own phone after installing the APK (power + volume down).
