#!/usr/bin/env bash
# Downloads the PDF engines once, at build time, and packs them inside the app so it works fully offline.
set -euo pipefail
DEST="app/src/main/assets/lib"
mkdir -p "$DEST"
TMP="$(mktemp -d)"
( cd "$TMP" && npm init -y >/dev/null && npm install --ignore-scripts --no-audit --no-fund \
    pdf-lib@1.17.1 pdfjs-dist@3.11.174 jszip@3.10.1 mammoth@1.6.0 >/dev/null )
pick () {   # pick <package> <file name> : copies the first match into the app
  local found
  found="$(find "$TMP/node_modules/$1" -type f -name "$2" -not -path '*/legacy/*' -not -path '*/es5/*' | head -n 1)"
  if [ -z "$found" ]; then echo "Could not find $2 inside $1"; exit 1; fi
  cp "$found" "$DEST/$2"
}
pick pdf-lib pdf-lib.min.js
pick pdfjs-dist pdf.min.js
pick pdfjs-dist pdf.worker.min.js
pick jszip jszip.min.js
pick mammoth mammoth.browser.min.js
for f in pdf-lib.min.js pdf.min.js pdf.worker.min.js jszip.min.js mammoth.browser.min.js; do
  test -s "$DEST/$f" || { echo "$f is empty"; exit 1; }
done
echo "PDF engines ready:"; ls -l "$DEST"
