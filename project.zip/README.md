# PDF Magic: Android app project

Everything below is done **from your phone**. No laptop needed.
You get a real Android app: an APK to install, and an AAB for Google Play. It works offline and needs **Android 10 or newer**.

The signing key for Google Play is **already inside this project** (`signing` folder). You do not need to make a key or add any GitHub secrets.

---

## Build the app (3 steps, about 15 minutes)

1. Create a free account at **github.com**. Tap **+ > New repository**, name it `pdfmagic`, choose **Private** (important), tap **Create**.
   Tap **uploading an existing file**, upload **`project.zip`** (do not unzip it), tap **Commit changes**.
2. Tap **Add file > Create new file**. In the name box type exactly `.github/workflows/build.yml`.
   Open the attached **`build.yml`**, copy all its text, paste it in, tap **Commit changes**.
3. Open the **Actions** tab (tap **I understand my workflows, enable them** if asked).
   Tap **PDF Magic app builder > Run workflow > build-app > Run workflow**.
   (No buttons? Open your browser menu and turn on **Desktop site**.)

After about 8 to 15 minutes there is a green tick. Tap the run, scroll down to **Artifacts**:
- **PDF-Magic-APK**: download, extract, tap the `.apk` to install on your phone.
- **PDF-Magic-PlayStore-AAB**: download, extract. The `app-release.aab` inside is the file for Google Play.

Both are already signed with the key in the `signing` folder.

## Keep safe

- Keep the repository **Private**. The signing key is inside `project.zip`.
- Keep a copy of `project.zip` somewhere safe (Google Drive). It holds your key. Do not share it.
- Google Play re-signs your app with its own key (Play App Signing), so this key is only your "upload key". If it is ever lost or leaked, Google Play can reset it. Only someone who also has your Play Console login can upload.

## Put it on Google Play

1. Create a Play Console developer account at **play.google.com/console** (one-time fee, identity check).
2. **Create app**: name `PDF Magic`, App, Free.
3. Fill the **App content** pages. Ready answers are in `store/listing.md`.
4. **Store listing**: paste the texts from `store/listing.md`; upload `store/play-icon-512.png`, `store/feature-graphic-1024x500.png` and 2 or more phone screenshots from your own phone.
5. **Testing > Closed testing > Create release**: upload the `.aab`. Keep Google's default for app signing.
6. New personal accounts must run the closed test with 12 testers opted in for 14 days in a row, then apply for production access. Organization accounts do not. Check the Play Console dashboard for the current rules.

Every new build gets a higher version number automatically, so uploads are always accepted.

## Privacy policy page (Google Play needs a web address)

1. Create a second, **public** repository named `pdfmagic-privacy`.
2. Upload `docs/privacy.html`, renamed to `index.html`. First open it and replace `[YOUR NAME]`, `[YOUR EMAIL]` and `[DATE]`.
3. **Settings > Pages > Branch: main > Save**. After a minute your page is at `https://YOUR-NAME.github.io/pdfmagic-privacy/`. Paste that address in Play Console.

## Update the app later

Upload a new `project.zip` to the repository (same name, it replaces the old one). The robot builds again by itself.

## Optional: use your own key

Run the workflow with `make-signing-key` and add 4 GitHub secrets (`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`). Secrets win over the key in the `signing` folder. Only do this if you already uploaded an app with another key.

## If the build fails (red cross)

Tap the failed run, open the red step, copy the last 30 lines and send them to me.
