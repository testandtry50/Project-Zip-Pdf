# PDF Magic: Android app project

Everything below can be done **from your phone**. You need no laptop.

What you get: a real Android app (APK for your phone, AAB for Google Play). The whole app is packed inside, so it works offline.
It needs **Android 10 or newer**.

---

## Part A. Build the app (about 15 minutes, first time)

1. Create a free account at **github.com**.
2. Tap **+ > New repository**. Name it `pdfmagic`. Choose **Private** (important). Tap **Create repository**.
3. On the new empty repository page, tap **uploading an existing file** (or **Add file > Upload files**).
   Upload **`project.zip`** (this zip file, do not unzip it). Tap **Commit changes**.
4. Add the build robot. Tap **Add file > Create new file**. In the name box type exactly:
   `.github/workflows/build.yml`
   Open the attached file **`build.yml`**, copy all of its text, paste it into the big box, then tap **Commit changes**.
5. Tap the **Actions** tab. If asked, tap **I understand my workflows, enable them**.
   Tap **PDF Magic app builder** > **Run workflow** > leave `build-app` > **Run workflow**.
   (If you do not see the buttons, open your browser menu and turn on **Desktop site**.)
6. Wait about 8 to 15 minutes until you see a green tick. Tap the finished run.
7. At the bottom, under **Artifacts**, tap **PDF-Magic-APK** to download. Unzip it and tap the `.apk` to install.
   (Android asks to allow installing from your browser or Files app. Allow it.)

The APK from Part A uses a test signature. It is perfect for trying the app. For Google Play you need Part B.

## Part B. Make your Play Store signing key (once)

1. **Actions > PDF Magic app builder > Run workflow**. Choose `make-signing-key`.
   In **key_password** type a password you will remember (8 or more letters and numbers). Run it.
2. When it finishes, download the artifact **signing-key**. Unzip it. Keep `pdfmagic-upload.jks` somewhere safe (Google Drive). If you lose it you can still recover through Google Play, but keep it safe anyway.
3. In your repository open **Settings > Secrets and variables > Actions > New repository secret** and add 4 secrets:
   - `KEYSTORE_BASE64` = the whole text inside `keystore-base64.txt`
   - `KEYSTORE_PASSWORD` = your password
   - `KEY_ALIAS` = `pdfmagic`
   - `KEY_PASSWORD` = your password (same)
4. Run **build-app** again (Part A, step 5). Now the artifacts are signed with your key.
   Download **PDF-Magic-PlayStore-AAB**. This `.aab` file is what Google Play wants.

Keep the repository **Private**: the key download is inside the workflow.

## Part C. Put it on Google Play

1. Create a Play Console developer account at **play.google.com/console** (one-time fee, set by Google).
2. **Create app**: name `PDF Magic`, language, App, Free.
3. Fill the **App content** pages. Ready answers are in `store/listing.md`.
4. **Store listing**: paste the texts from `store/listing.md` and upload `store/play-icon-512.png`, `store/feature-graphic-1024x500.png` and your phone screenshots.
5. **Testing or Production > Create new release**. Choose **Play App Signing** when asked. Upload the `.aab`. Save, review, roll out.
6. New personal developer accounts may have to run a **closed test** with a number of testers for a number of days before production is allowed. Check the dashboard for the current rules.

Every new upload needs a higher version number. The robot does this for you automatically (it uses the run number).

## Part D. Privacy policy page (Google Play requires a web address)

1. Create a second, **public** repository named `pdfmagic-privacy`.
2. Upload `docs/privacy.html` renamed to `index.html`. Before committing, open the file and replace `[YOUR NAME]`, `[YOUR EMAIL]` and `[DATE]`.
3. **Settings > Pages > Branch: main > Save.** After a minute your page is at `https://YOUR-NAME.github.io/pdfmagic-privacy/`. Paste that address into Play Console.

## Part E. Update the app later

Upload a new `project.zip` to the repository (same name, it replaces the old one). The robot builds automatically.

---

## What is inside the app

- Strict security: no internet permission, no storage or camera permission, web view locked down, content security policy, no backups, files from other apps accepted only as `content://`.
- Saves to Downloads/PDF Magic. Share and Print use the normal Android screens.
- Settings: light/dark theme, hide in recent apps and block screenshots, unlock with phone lock.
- "Open with" and "Share to" PDF Magic from other apps.

## If the build fails (red cross)

Tap the failed run, open the red step, copy the last 30 lines and send them to me. Most problems are a typo in `build.yml`.
