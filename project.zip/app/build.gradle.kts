import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Signing: GitHub secrets win if you set them; otherwise the key inside the "signing" folder is used.
fun env(name: String): String? = System.getenv(name)?.takeIf { it.isNotBlank() }
val keyProps = Properties().apply {
    val f = rootProject.file("signing/key.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val keystorePath: String? = (env("KEYSTORE_PATH") ?: keyProps.getProperty("storeFile")?.let { rootProject.file(it).path })
    ?.takeIf { file(it).exists() }
val buildNumber: Int = System.getenv("VERSION_CODE")?.toIntOrNull() ?: 1

android {
    namespace = "com.pdfmagic.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.pdfmagic.app"
        minSdk = 29
        targetSdk = 36
        versionCode = buildNumber
        versionName = "1.0.$buildNumber"
    }

    signingConfigs {
        if (keystorePath != null) {
            create("release") {
                storeFile = file(keystorePath)
                storePassword = env("KEYSTORE_PASSWORD") ?: keyProps.getProperty("storePassword")
                keyAlias = env("KEY_ALIAS") ?: keyProps.getProperty("keyAlias")
                keyPassword = env("KEY_PASSWORD") ?: keyProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = if (keystorePath != null) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
}
