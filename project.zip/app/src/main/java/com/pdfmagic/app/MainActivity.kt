package com.pdfmagic.app

import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * PDF Magic: the whole app (HTML/JS/CSS) is bundled inside the APK and runs offline in a locked-down WebView.
 * This class only adds what a web page cannot do: saving to Downloads, sharing, printing, opening files from
 * other apps, the camera, and optional privacy features (screenshot block, unlock with phone lock).
 */
class MainActivity : AppCompatActivity() {

    private companion object {
        const val HOST = "appassets.androidplatform.net"
        const val START_URL = "https://$HOST/assets/index.html"
        const val LOCK_AFTER_MS = 30_000L
    }

    private class SharedFile(val id: String, val uri: Uri, val name: String, val mime: String, val kind: String)
    private class Out(val file: File, val stream: FileOutputStream, val name: String, val mime: String, val mode: String)

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("pdfmagic", MODE_PRIVATE) }

    private val outs = ConcurrentHashMap<String, Out>()
    private val shared = ConcurrentHashMap<String, SharedFile>()
    private val pendingShared = ArrayList<SharedFile>()

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private var locking = false
    private var unlockedOnce = false
    private var leftAt = 0L

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = fileCallback
        fileCallback = null
        if (cb != null) {
            var result: Array<Uri>? = null
            if (r.resultCode == RESULT_OK) {
                val data = r.data
                val clip = data?.clipData
                val single = data?.data
                val photo = cameraUri
                result = when {
                    clip != null && clip.itemCount > 0 -> Array(clip.itemCount) { clip.getItemAt(it).uri }
                    single != null -> arrayOf(single)
                    photo != null -> arrayOf(photo)
                    else -> null
                }
            }
            cb.onReceiveValue(result)
        }
        cameraUri = null
    }

    private val lockLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        locking = false
        if (r.resultCode == RESULT_OK) {
            unlockedOnce = true
            web.visibility = View.VISIBLE
        } else {
            finish()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(nightMode(prefs.getString("theme", "system")))
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Temporary files from earlier sessions are removed every time the app starts.
        for (d in listOf("out", "share", "camera")) File(cacheDir, d).deleteRecursively()
        applyPrivacy()

        root = FrameLayout(this)
        root.setBackgroundColor(getColor(R.color.app_bg))
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        // Android 15+ always draws apps edge to edge, so keep the page clear of the status bar, navigation bar and keyboard.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        setupWebView()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(function(){return !!(window.nativeBack && window.nativeBack());})()") { r ->
                    if (r != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        handleIntent(intent)
        web.loadUrl(START_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.cacheMode = WebSettings.LOAD_NO_CACHE
        s.blockNetworkLoads = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.mediaPlaybackRequiresUserGesture = true
        WebView.setWebContentsDebuggingEnabled(false)
        web.setBackgroundColor(getColor(R.color.app_bg))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.addJavascriptInterface(Bridge(), "PDFMagicNative")
        web.setDownloadListener { _, _, _, _, _ -> }   // files are saved through the bridge, never through the web view

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return blocked()
                val scheme = u.scheme
                if (scheme == "blob" || scheme == "data") return null
                if (scheme != "https" || u.host != HOST) return blocked()
                val path = u.path ?: ""
                if (path.contains("/__shared__/")) return sharedResponse(path.substringAfterLast('/'))
                return loader.shouldInterceptRequest(u) ?: blocked()
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                recreate()
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                if (callback == null || params == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                try {
                    val intent: Intent
                    if (params.isCaptureEnabled) {
                        val dir = File(cacheDir, "camera").apply { mkdirs() }
                        val photo = File(dir, "scan_" + System.currentTimeMillis() + ".jpg")
                        val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", photo)
                        cameraUri = uri
                        intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                            .putExtra(MediaStore.EXTRA_OUTPUT, uri)
                            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } else {
                        intent = params.createIntent()
                    }
                    chooser.launch(intent)
                } catch (e: Exception) {
                    fileCallback = null
                    callback.onReceiveValue(null)
                }
                return true
            }
        }
    }

    private fun blocked() = WebResourceResponse(
        "text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0))
    )

    private fun sharedResponse(id: String): WebResourceResponse? {
        val f = shared[id] ?: return blocked()
        return try {
            val stream = contentResolver.openInputStream(f.uri) ?: return blocked()
            WebResourceResponse(f.mime, null, 200, "OK", mapOf("Cache-Control" to "no-store"), stream)
        } catch (e: Exception) {
            blocked()
        }
    }

    // ---------- files sent from other apps ----------

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_VIEW -> i.data?.let { uris.add(it) }
            Intent.ACTION_SEND -> {
                val u = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                if (u != null) uris.add(u)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val l = if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                if (l != null) uris.addAll(l)
            }
        }
        // Only content:// addresses are accepted. file:// addresses from other apps could point at this app's private files.
        val safe = uris.filter { it.scheme == "content" }.take(30)
        if (safe.isEmpty()) return
        val kind = if (i.action == Intent.ACTION_VIEW) "view" else "send"
        synchronized(pendingShared) {
            for (u in safe) {
                val item = SharedFile(
                    UUID.randomUUID().toString(), u, nameOf(u), contentResolver.getType(u) ?: "application/octet-stream", kind
                )
                shared[item.id] = item
                pendingShared.add(item)
            }
        }
        if (::web.isInitialized) {
            web.post { web.evaluateJavascript("window.nativeShared&&window.nativeShared()", null) }
        }
    }

    private fun nameOf(u: Uri): String {
        var n = "document"
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0) ?: n
            }
        } catch (e: Exception) {
            // keep the default name
        }
        return n
    }

    // ---------- light / dark ----------

    private fun nightMode(t: String?) = when (t) {
        "dark" -> AppCompatDelegate.MODE_NIGHT_YES
        "light" -> AppCompatDelegate.MODE_NIGHT_NO
        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    }

    // ---------- privacy and lock ----------

    private fun applyPrivacy() {
        if (prefs.getBoolean("privacy", false)) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    override fun onStop() {
        super.onStop()
        leftAt = SystemClock.elapsedRealtime()
    }

    override fun onStart() {
        super.onStart()
        checkLock()
    }

    private fun checkLock() {
        if (!prefs.getBoolean("lock", false) || locking) return
        if (unlockedOnce && SystemClock.elapsedRealtime() - leftAt < LOCK_AFTER_MS) return
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val ask = km.createConfirmDeviceCredentialIntent(getString(R.string.app_name), getString(R.string.unlock_msg)) ?: return
        locking = true
        web.visibility = View.INVISIBLE
        lockLauncher.launch(ask)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        enableEdgeToEdge()   // status and navigation bar icons follow the light or dark theme
        root.setBackgroundColor(getColor(R.color.app_bg))
        web.setBackgroundColor(getColor(R.color.app_bg))
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            root.removeView(web)
            web.destroy()
        }
        super.onDestroy()
    }

    // ---------- the bridge the page talks to ----------

    inner class Bridge {

        @JavascriptInterface
        fun begin(name: String, mime: String, mode: String): String {
            val dir = File(cacheDir, "out").apply { mkdirs() }
            val id = UUID.randomUUID().toString()
            val safe = name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().take(120).ifEmpty { "document" }
            val f = File(dir, id)
            outs[id] = Out(f, FileOutputStream(f), safe, mime.ifEmpty { "application/octet-stream" }, mode)
            return id
        }

        @JavascriptInterface
        fun chunk(id: String, base64: String) {
            outs[id]?.stream?.write(Base64.decode(base64, Base64.DEFAULT))
        }

        @JavascriptInterface
        fun end(id: String): String {
            val o = outs.remove(id) ?: return ""
            o.stream.close()
            return try {
                deliver(o)
            } catch (e: Exception) {
                "Could not finish: " + (e.message ?: "unknown error")
            }
        }

        @JavascriptInterface
        fun takeShared(): String {
            val arr = JSONArray()
            synchronized(pendingShared) {
                for (s in pendingShared) {
                    arr.put(JSONObject().put("id", s.id).put("name", s.name).put("mime", s.mime).put("kind", s.kind))
                }
                pendingShared.clear()
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun getSettings(): String = JSONObject()
            .put("privacy", prefs.getBoolean("privacy", false))
            .put("lock", prefs.getBoolean("lock", false))
            .toString()

        @JavascriptInterface
        fun setTheme(mode: String) {
            val m = if (mode == "dark" || mode == "light") mode else "system"
            prefs.edit().putString("theme", m).apply()
            runOnUiThread { AppCompatDelegate.setDefaultNightMode(nightMode(m)) }
        }

        @JavascriptInterface
        fun setPrivacy(on: Boolean) {
            prefs.edit().putBoolean("privacy", on).apply()
            runOnUiThread { applyPrivacy() }
        }

        @JavascriptInterface
        fun setLock(on: Boolean): Boolean {
            if (on && !(getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure) return false
            prefs.edit().putBoolean("lock", on).apply()
            unlockedOnce = on
            leftAt = SystemClock.elapsedRealtime()
            return true
        }

        @JavascriptInterface
        fun version(): String = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    private fun deliver(o: Out): String {
        when (o.mode) {
            "save" -> {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, o.name)
                    put(MediaStore.Downloads.MIME_TYPE, o.mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PDF Magic")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return "Could not save the file."
                val out = contentResolver.openOutputStream(uri) ?: return "Could not save the file."
                out.use { target -> FileInputStream(o.file).use { it.copyTo(target) } }
                val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                contentResolver.update(uri, done, null, null)
                o.file.delete()
                return "Saved in Downloads/PDF Magic"
            }
            "share" -> {
                val dir = File(cacheDir, "share").apply { mkdirs() }
                val f = File(dir, o.name)
                o.file.copyTo(f, overwrite = true)
                o.file.delete()
                val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
                runOnUiThread {
                    val send = Intent(Intent.ACTION_SEND)
                        .setType(o.mime)
                        .putExtra(Intent.EXTRA_STREAM, uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    send.clipData = ClipData.newRawUri(o.name, uri)
                    startActivity(Intent.createChooser(send, getString(R.string.share_title)))
                }
                return ""
            }
            "print" -> {
                runOnUiThread {
                    val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    pm.print(o.name, FilePrintAdapter(o.file, o.name), null)
                }
                return ""
            }
        }
        return ""
    }
}

/** Hands a finished PDF file to Android's print system (so Print and "Save as PDF" both work). */
private class FilePrintAdapter(private val file: File, private val title: String) : PrintDocumentAdapter() {

    override fun onLayout(
        oldAttributes: PrintAttributes?, newAttributes: PrintAttributes?, cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback, extras: Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback.onLayoutCancelled()
            return
        }
        val info = PrintDocumentInfo.Builder(title)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
            .build()
        callback.onLayoutFinished(info, true)
    }

    override fun onWrite(
        pages: Array<out PageRange>?, destination: ParcelFileDescriptor, cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback
    ) {
        try {
            FileInputStream(file).use { input -> FileOutputStream(destination.fileDescriptor).use { input.copyTo(it) } }
            callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (e: Exception) {
            callback.onWriteFailed(e.message)
        }
    }
}
