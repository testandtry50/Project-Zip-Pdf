const NA = window.PDFMagicNative || null;

const {PDFDocument, degrees} = PDFLib;
const $ = s => document.querySelector(s);
const esc = s => s.replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fmtSize = n => n > 1e6 ? (n/1e6).toFixed(1)+' MB' : Math.max(1,Math.round(n/1e3))+' KB';
const isPdf = f => f.type === 'application/pdf' || /\.pdf$/i.test(f.name);
const isImg = f => f.type.startsWith('image/') || /\.(jpe?g|png|gif|webp|bmp|avif|heic|heif)$/i.test(f.name);
let items = [], uid = 0, built = null, busy = false, cancelFlag = false, armT, rq;
class Cancelled extends Error{}
const tick = () => new Promise(r => setTimeout(r));
const queueRender = () => { cancelAnimationFrame(rq); rq = requestAnimationFrame(render); };
function showProg(f, label){ if(label) showProg.l = label; const v = Math.round((pr[0] + f * (pr[1] - pr[0])) * 100); $('#fill').style.width = v+'%'; $('#pt').textContent = v+'%, '+pfx+showProg.l; }

// pdf.worker is loaded as a normal script above, so pdf.js runs without a Web Worker (works when opened from disk or in-app)
pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';

function toast(msg){ const t=$('#toast'); t.textContent=msg; t.hidden=false; clearTimeout(toast.t); toast.t=setTimeout(()=>t.hidden=true,5000); }

/* ---------- list ---------- */
$('#file').onchange = e => { add([...e.target.files]); e.target.value = ''; };
const dz = $('#drop');
['dragenter','dragover'].forEach(n => dz.addEventListener(n, e => { e.preventDefault(); dz.classList.add('on'); }));
['dragleave','drop'].forEach(n => dz.addEventListener(n, e => { e.preventDefault(); dz.classList.remove('on'); }));
dz.addEventListener('drop', e => add([...e.dataTransfer.files]));
$('#sort').onchange = () => { sortItems(); render(); };
const Q = {orig:null, high:{edge:3000,q:.9}, med:{edge:2000,q:.75}, low:{edge:1200,q:.55}, min:{edge:800,q:.4}};
const CQO = [['','Quality: main setting'], ['orig','Quality: original'], ['high','Quality: high'], ['med','Quality: medium'], ['low','Quality: low'], ['min','Quality: smallest']];
const CQN = Object.fromEntries(CQO);
let curL = 1, pr = [0, 1], pfx = '';           // curL: tuning level (1 = your settings, lower = smaller) used by the target-size search
const tn = m => { const t = m.tune ? curL : 1; return {f:m.tune ? .35 + .65*t : 1, q:Math.max(.2, m.q * (m.tune ? .55 + .45*t : 1))}; };
function cfg(){
  const v = $('#qual').value; if(v === 'orig') return null;
  const tg = +$('#ctg').value || 0;
  return {edge:+$('#cpx').value || 0, q:Math.min(1, Math.max(.2, (+$('#cq').value || 85) / 100)), flatten:$('#cfl').checked, tune:tg > 0, target:tg * 1e6};
}
$('#size').onchange = () => { built = null; };
$('#qual').onchange = () => {
  built = null; const v = $('#qual').value, m = Q[v]; $('#cp').hidden = v === 'orig'; segQ();
  if(m){ $('#cpx').value = m.edge; $('#cq').value = Math.round(m.q * 100); }
  $('#cqv').textContent = $('#cq').value + '%';
  $('#qh').textContent = v === 'orig' ? 'Nothing is re-compressed. Largest file, best for printing and archiving.'
    : 'Pictures get smaller and are saved as JPEG. Text in PDFs stays sharp. Enter a size in MB under Custom and the best quality that fits is chosen for you.';
};
['#cpx', '#cq'].forEach(id => $(id).oninput = () => { built = null; $('#qual').value = 'custom'; segQ(); $('#cqv').textContent = $('#cq').value + '%'; });
['#ctg', '#cfl'].forEach(id => $(id).oninput = () => { built = null; });
$('#list').onchange = e => {
  const sel = e.target.closest('[data-a="cq"]'); if(!sel) return;
  items.find(x => x.id === +sel.closest('li').dataset.id).cm = sel.value; built = null;
};

async function snap(files){                           // copies each picked file into memory right away: phone gallery links can stop working a few seconds later
  const out = []; let bad = 0;
  for(let i = 0; i < files.length; i++){
    const f = files[i]; if(files.length > 2){ toast(`Reading your files… ${i + 1} of ${files.length}`); await tick(); }
    try{ out.push(new File([await f.arrayBuffer()], f.name, {type:f.type, lastModified:f.lastModified})); }catch(e){ bad++; }
  }
  if(bad) toast(`${bad} file${bad > 1 ? 's' : ''} could not be read and ${bad > 1 ? 'were' : 'was'} skipped. Please pick ${bad > 1 ? 'them' : 'it'} again.`);
  else if(files.length > 2) toast(`${files.length} files ready.`);
  return out;
}
async function add(files){
  if($('#task').value === 'zipedit'){ const z = files.filter(isZip); if(!z.length) return toast('Choose a .zip file.'); return openZipEditor(z); }
  const T = TASKS[$('#task').value]; files = files.filter(f => (T.acc !== 'img' && isPdf(f)) || (T.acc !== 'pdf' && isImg(f)));
  if(!files.length) return toast(T.acc === 'pdf' ? 'This task only uses PDF files.' : T.acc === 'img' ? 'This task only uses photos.' : 'Choose PDF or image files.');
  files = await snap(files); if(!files.length) return;
  files.forEach(f => { const pdf = isPdf(f); items.push({id:++uid, file:f, kind:pdf?'pdf':'img', date:f.lastModified, done:!pdf, thumb:pdf?'':URL.createObjectURL(f)}); });
  sortItems(); render();
  for(const it of items) if(!it.done) await makeThumb(it);
  if(!skipAuto && $('#task').value === 'edit'){ const u = usable(); if(u.length === 1 && u[0].kind === 'pdf') openEditor(u[0]); }
  if(!skipAuto && $('#task').value === 'split'){ const f = items.find(i => i.file === files[0]); if(f && !f.err) openItemSplit(f); }
  if(!skipAuto && $('#task').value === 'read'){ const f = items.find(i => i.file === files[0]); if(f && !f.err) openViewer(f.file.name, new Uint8Array(await f.file.arrayBuffer())); }
}
const byName = (a,b) => a.file.name.localeCompare(b.file.name, undefined, {numeric:true});
function sortItems(){
  const m = $('#sort').value; if(m === 'manual') return;
  const by = {old:(a,b)=>a.date-b.date, new:(a,b)=>b.date-a.date, name:byName};
  items.sort((a,b) => by[m](a,b) || byName(a,b));
}
async function makeThumb(it){
  it.done = true;
  try{
    if(it.kind === 'img'){ it.thumb = URL.createObjectURL(it.file); }
    else{
      const pdf = await pdfjsLib.getDocument({data:new Uint8Array(await it.file.arrayBuffer())}).promise;
      it.pages = pdf.numPages;
      const p = await pdf.getPage(1), w = p.getViewport({scale:1}).width;
      const v = p.getViewport({scale:140/w});
      const c = document.createElement('canvas'); c.width = v.width; c.height = v.height;
      await p.render({canvasContext:c.getContext('2d'), viewport:v}).promise;
      it.thumb = c.toDataURL('image/jpeg', .7); pdf.destroy();
    }
  }catch(e){
    if(/password/i.test(e.name+e.message)) it.err = 'Password-protected, cannot be merged';
    else{
      try{ it.pages = (await PDFDocument.load(await it.file.arrayBuffer())).getPageCount(); it.noPrev = true; }   // preview failed, merging still works
      catch(e2){ it.err = /encrypt/i.test(e2.message) ? 'Password-protected, cannot be merged' : 'Could not read this file: ' + String(e2.message || e2).slice(0, 90); }
    }
  }
  queueRender();
}
function render(){
  built = null; disarm();
  $('#list').innerHTML = items.length ? items.map((it,i) => `<li data-id="${it.id}">
    <button class="th" data-a="view" aria-label="Preview ${esc(it.file.name)}">${it.thumb?`<img src="${it.thumb}" alt="" loading="lazy" decoding="async">`:''}<i>${i+1}</i></button>
    <div><div class="nm"><span class="bd ${it.kind}">${it.kind === 'pdf' ? 'PDF' : 'IMG'}</span>${esc(it.file.name)}</div>
      <div class="sub">${it.kind==='pdf'?'PDF'+(it.pages?', '+(it.pg?it.pg.length:it.pages)+' pages'+(it.pg?', edited':''):''):'Image'}, ${fmtSize(it.file.size)}</div>
      <div class="sub">${new Date(it.date).toLocaleString([], {dateStyle:'medium', timeStyle:'short'})}</div>
      ${it.err?`<div class="er">${esc(it.err)}</div>`:''}
      ${it.err?'':`<details class="mo"><summary>More tools</summary><div class="rw">${it.kind==='pdf'&&!it.noPrev?'<button class="b sm" data-a="edit">Edit pages</button><button class="b sm" data-a="ec">Edit content</button><button class="b sm" data-a="split">Split</button>':''}<button class="b sm" data-a="one">Save only this</button><select data-a="cq" aria-label="Quality for this file">${CQO.map(([v, t]) => `<option value="${v}"${(it.cm||'')===v?' selected':''}>${t}</option>`).join('')}</select></div></details>`}</div>
    <div class="ac"><button data-a="up" aria-label="Move up">↑</button><button data-a="dn" aria-label="Move down">↓</button><button data-a="rm" aria-label="Remove">✕</button></div>
  </li>`).join('') : '<li class="empty" style="display:block;border:0;background:none;margin:0">Nothing added yet.</li>';
  const ok = usable().length;
  $('#st').textContent = items.length ? `${ok} file${ok===1?'':'s'} ready` + (items.length>ok?`, ${items.length-ok} skipped`:'') : 'No files yet';
  $('#merge').disabled = $('#prev').disabled = !ok;
  $('#lh').hidden = !items.length; const noSteps = ['read', 'split', 'zipedit'].includes($('#task').value); $('#s2').hidden = !items.length || $('#task').value === 'zipedit'; $('#s3').hidden = $('#bar').hidden = !items.length || noSteps;
  [...$('#list').children].forEach((li, i) => { const it = items[i]; if(it && !fits(it)){ li.style.opacity = .5; const sb = li.querySelector('.sub'); if(sb) sb.textContent += ' (not used in this task)'; } });
  sync(); $('#cnt').textContent = `${items.length} file${items.length===1?'':'s'} added, ${fmtSize(items.reduce((a, i) => a + i.file.size, 0))}`;
}
function disarm(){ clearTimeout(armT); const b = $('#clear'); delete b.dataset.arm; b.textContent = 'Clear all'; }
$('#clear').onclick = e => {
  const b = e.currentTarget;
  if(!b.dataset.arm){ b.dataset.arm = 1; b.textContent = `Tap again to remove all ${items.length}`; armT = setTimeout(disarm, 3500); return; }
  if(busy) cancelFlag = true;
  items.forEach(i => { if(i.kind === 'img') URL.revokeObjectURL(i.thumb); });
  items.length = 0; docCache.clear(); render(); toast('All files removed.');
};
$('#stop').onclick = () => { cancelFlag = true; $('#pt').textContent = 'Cancelling…'; };
$('#list').onclick = async e => {
  const b = e.target.closest('[data-a]'); if(!b) return;
  const i = items.findIndex(x => x.id === +b.closest('li').dataset.id), it = items[i], a = b.dataset.a;
  if(a === 'cq') return;
  if(a === 'one') return run(r => save(r), it);
  if(a === 'split') return openItemSplit(it);
  if(a === 'ec') return openItemCE(it);
  if(a === 'edit') return openEditor(it);
  if(a === 'view'){
    if(it.err) return;
    return it.kind === 'img' ? openViewer(it.file.name, null, {img:it.thumb})
      : openViewer(it.file.name, new Uint8Array(await it.file.arrayBuffer()));
  }
  if(a === 'rm'){ if(it.kind==='img') URL.revokeObjectURL(it.thumb); items.splice(i,1); }
  else{
    const j = i + (a==='up' ? -1 : 1); if(j < 0 || j >= items.length) return;
    [items[i], items[j]] = [items[j], items[i]]; $('#sort').value = 'manual';
  }
  render();
};

/* ---------- build the merged PDF ---------- */
function exifRot(b){
  try{
    const v = new DataView(b.buffer, b.byteOffset, b.byteLength); let o = 2;
    while(o + 4 < v.byteLength){
      const m = v.getUint16(o), l = v.getUint16(o+2);
      if(m === 0xFFE1 && v.getUint32(o+4) === 0x45786966){
        const t = o+10, le = v.getUint16(t) === 0x4949;
        let p = t + v.getUint32(t+4, le); const n = v.getUint16(p, le); p += 2;
        for(let k=0; k<n; k++, p+=12) if(v.getUint16(p, le) === 0x112)
          return ({3:180, 6:90, 8:270, 5:270, 7:90})[v.getUint16(p+8, le)] || 0;
        return 0;
      }
      if((m & 0xFF00) !== 0xFF00 || m === 0xFFDA) return 0;
      o += 2 + l;
    }
  }catch(e){}
  return 0;
}
async function toPng(file){
  const bmp = await createImageBitmap(file);
  const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height;
  c.getContext('2d').drawImage(bmp, 0, 0);
  const blob = await new Promise(r => c.toBlob(r, 'image/png'));
  return new Uint8Array(await blob.arrayBuffer());
}
async function shrink(file, m){          // re-encode as JPEG, EXIF rotation applied by the browser
  let bmp; try{ bmp = await createImageBitmap(file, {imageOrientation:'from-image'}); }catch(e){ bmp = await createImageBitmap(file); }
  const {f, q} = tn(m), k = Math.min(1, m.edge ? m.edge / Math.max(bmp.width, bmp.height) : 1) * f;
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width*k); c.height = Math.round(bmp.height*k);
  const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
  const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', q));
  const res = {bytes:new Uint8Array(await blob.arrayBuffer()), w:bmp.width, h:bmp.height}; if(bmp.close) bmp.close(); return res;
}
async function addImage(out, file, buf, size, m){
  const bytes = new Uint8Array(buf); let img, rot = 0, rw, rh;
  const jpg = bytes[0] === 0xFF && bytes[1] === 0xD8, png = bytes[0] === 0x89 && bytes[1] === 0x50;
  if(m){ try{                               // never make an image bigger than the original
    const sm = await shrink(file, m);
    if(!(jpg || png) || sm.bytes.length < file.size){ img = await out.embedJpg(sm.bytes); rw = sm.w; rh = sm.h; }
  }catch(e){} }
  if(!img && jpg){ rot = exifRot(bytes); img = await out.embedJpg(bytes); }   // original JPEG data, untouched
  else if(!img && png){ try{ img = await out.embedPng(bytes); }catch(e){} }
  if(!img) img = await out.embedPng(await toPng(file));                                                  // lossless PNG for other formats
  rw = rw || img.width; rh = rh || img.height; const sw = rot % 180, dW = sw ? rh : rw, dH = sw ? rw : rh;
  let pW, pH, s;
  if(size === 'a4'){ [pW,pH] = dH >= dW ? [595.28,841.89] : [841.89,595.28]; s = Math.min(pW/dW, pH/dH); }
  else{ s = .75; pW = dW*s; pH = dH*s; }
  const bW = sw ? pH : pW, bH = sw ? pW : pH;
  const page = out.addPage([bW, bH]); if(rot) page.setRotation(degrees(rot));
  page.drawImage(img, {x:(bW-rw*s)/2, y:(bH-rh*s)/2, width:rw*s, height:rh*s});
}
async function rasterPdf(out, file, buf, m, prog){   // true if pages were added as smaller JPEG images
  const pdf = await pdfjsLib.getDocument({data:new Uint8Array(buf.slice(0))}).promise, pages = []; let total = 0;
  try{
    for(let n = 1; n <= pdf.numPages; n++){
      if(cancelFlag) throw new Cancelled(); prog((n-1)/pdf.numPages); await tick();
      const p = await pdf.getPage(n), v0 = p.getViewport({scale:1});
      const {f, q} = tn(m), v = p.getViewport({scale:Math.min((m.edge || 2000) * f / Math.max(v0.width, v0.height), Math.sqrt(16e6/(v0.width*v0.height)))});
      const c = document.createElement('canvas'); c.width = Math.ceil(v.width); c.height = Math.ceil(v.height);
      const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
      await p.render({canvasContext:g, viewport:v}).promise;
      const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', q)), bytes = new Uint8Array(await blob.arrayBuffer());
      total += bytes.length; if(total >= file.size) return false;   // not smaller: keep the original pages
      pages.push({bytes, w:v0.width, h:v0.height});
    }
  }finally{ pdf.destroy(); }
  for(const p of pages){ const img = await out.embedJpg(p.bytes); out.addPage([p.w, p.h]).drawImage(img, {x:0, y:0, width:p.w, height:p.h}); }
  return true;
}
function pageImgRefs(doc, idx){                // references of the pictures used by one page
  const {PDFName, PDFDict, PDFRef} = PDFLib, set = new Set();
  const walk = (res, depth) => {
    const xo = res && res.lookupMaybe(PDFName.of('XObject'), PDFDict); if(!xo || depth > 3) return;
    for(const [, v] of xo.entries()){
      const o = doc.context.lookup(v), st = String(o && o.dict && o.dict.get(PDFName.of('Subtype')));
      if(st === '/Image' && v instanceof PDFRef) set.add(String(v));
      else if(st === '/Form') walk(o.dict.lookupMaybe(PDFName.of('Resources'), PDFDict), depth + 1);
    }
  };
  try{ walk(doc.getPage(idx).node.Resources(), 0); }catch(e){}
  return set;
}
async function squeeze(doc, m, idx, prog){      // idx: page number, or null for the whole document
  const {PDFName, PDFRawStream, PDFNumber} = PDFLib, N = n => PDFName.of(n);
  const only = idx == null ? null : pageImgRefs(doc, idx), seen = doc._sq || (doc._sq = new Set());
  const list = doc.context.enumerateIndirectObjects().filter(([r, o]) => o instanceof PDFRawStream && !seen.has(String(r)) && (!only || only.has(String(r)))
    && String(o.dict.get(N('Subtype'))) === '/Image' && String(o.dict.get(N('Filter'))) === '/DCTDecode'
    && !o.dict.has(N('ImageMask')) && !o.dict.has(N('Mask')) && !o.dict.has(N('Decode')));
  let i = 0;
  for(const [ref, o] of list){
    seen.add(String(ref)); if(cancelFlag) throw new Cancelled(); if(prog) prog(i++ / list.length); await tick();
    try{
      const d = o.dict, w = d.get(N('Width')).asNumber(), h = d.get(N('Height')).asNumber(), {f, q} = tn(m);
      const k = Math.min(1, m.edge ? m.edge / Math.max(w, h) : 1) * f, blob0 = new Blob([o.contents], {type:'image/jpeg'});
      let bmp; try{ bmp = await createImageBitmap(blob0, {imageOrientation:'none'}); }catch(e){ bmp = await createImageBitmap(blob0); }
      const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w*k)); c.height = Math.max(1, Math.round(h*k));
      c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height); if(bmp.close) bmp.close();
      const nb = new Uint8Array(await (await new Promise(r => c.toBlob(r, 'image/jpeg', q))).arrayBuffer());
      if(nb.length < o.contents.length * .97){          // keep the original if the new one is not clearly smaller
        d.set(N('Width'), PDFNumber.of(c.width)); d.set(N('Height'), PDFNumber.of(c.height));
        d.set(N('ColorSpace'), N('DeviceRGB')); d.set(N('BitsPerComponent'), PDFNumber.of(8));
        doc.context.assign(ref, PDFRawStream.of(d, nb));
      }
    }catch(e){}
  }
}
async function buildOnce(G, list){
  const ok = list || usable(); if(!ok.length) throw new Error('Add at least one valid file.');
  const out = await PDFDocument.create(), size = $('#size').value;
  let n = 0; showProg(0, 'Starting…');
  for(const it of ok){
    if(cancelFlag) throw new Cancelled();
    showProg(n/ok.length, ok.length > 1 ? `File ${++n} of ${ok.length}: ${it.file.name}` : (++n, it.file.name)); await tick();
    try{
      const buf = await it.file.arrayBuffer(), m = it.cm ? Q[it.cm] : G;     // file setting beats main setting
      if(it.kind === 'pdf' && it.pg){ await addEdited(out, it, size, m, f => showProg((n-1+f)/ok.length)); }
      else if(it.kind === 'pdf'){
        if(!(m && m.flatten && await rasterPdf(out, it.file, buf, m, f => showProg((n-1+f)/ok.length)))){
          const src = await PDFDocument.load(buf);
          if(m) await squeeze(src, m, null, f => showProg((n-1+f)/ok.length));
          (await out.copyPages(src, src.getPageIndices())).forEach(p => out.addPage(p));
        }
      }else await addImage(out, it.file, buf, size, m);
    }catch(e){ if(e instanceof Cancelled) throw e; throw new Error(/could not be read any more/.test(e.message || '') ? e.message : `${it.file.name}: ${e.message || 'could not be added'}`); }
  }
  if(!out.getPageCount()) throw new Error('There are no pages to export.');
  showProg(.98, 'Finalizing PDF…'); await tick(); if(cancelFlag) throw new Cancelled();
  const bytes = await out.save();
  return {bytes, blob:new Blob([bytes], {type:'application/pdf'}), size:bytes.length};
}
const TASKS = {
  all:{d:'Add PDFs and photos. They are joined in order, using your size setting.', acc:'both', out:'one'},
  read:{d:'Open a PDF to read it. Search, zoom, copy text, share or print.', acc:'pdf', out:'one'},
  merge:{d:'Join several PDFs into one. Pages are copied untouched.', acc:'pdf', out:'one'},
  photos:{d:'Turn photos into a PDF. Each photo becomes a page.', acc:'img', out:'one'},
  compress:{d:'Make PDFs and photos smaller. Each file is saved as its own PDF.', acc:'both', out:'sep'},
  split:{d:'Cut a PDF into smaller PDFs, or pull some pages out into a new one.', acc:'pdf', out:'one'},
  zip:{d:'Pick many photos and get them in ONE ZIP file, in date order. PDFs can go in too. Photos can be made smaller.', acc:'both', out:'one'},
  zipedit:{d:'Open a ZIP to see what is inside. Rename, move, delete, add or replace files, rotate photos, compress, split or pull files out.', acc:'zip', out:'one'},
  edit:{d:'Open a PDF to rotate, delete, move or replace its pages.', acc:'pdf', out:'one'}
};
const fits = it => { const a = TASKS[$('#task').value].acc; return a === 'both' || (a === 'pdf') === (it.kind === 'pdf'); };
const usable = () => items.filter(i => !i.err && fits(i));
function sync(){                                      // buttons follow the chosen output
  document.querySelectorAll('#oseg [data-o]').forEach(b => b.classList.toggle('on', b.dataset.o === $('#outm').value));
  const zip = $('#outm').value === 'sep' && usable().length > 1;
  const zt = zipMode(); $('#prev').hidden = zip; $('#merge').textContent = (zip || zt) ? 'Save ZIP' : 'Save PDF';
}
function setTask(t){
  const T = TASKS[t], q = $('#qual'); $('#task').value = t;
  $('#tiles').querySelectorAll('.tile').forEach(b => b.classList.toggle('on', b.dataset.t === t));
  $('#td').textContent = T.d; $('#outm').value = T.out; $('#lsz').hidden = T.acc === 'pdf' || t === 'zip'; $('#oseg').parentElement.hidden = t === 'zip'; $('#zrow').hidden = t !== 'zip';
  if(['merged', 'photos'].includes($('#name').value.trim())) $('#name').value = t === 'zip' ? 'photos' : 'merged';
  $('#file').accept = T.acc === 'pdf' ? 'application/pdf,.pdf' : T.acc === 'img' ? 'image/*' : T.acc === 'zip' ? '.zip,application/zip,application/x-zip-compressed' : 'application/pdf,.pdf,image/*';
  if(t === 'merge' && q.value !== 'orig'){ q.value = 'orig'; q.onchange(); }
  if(t === 'compress' && q.value === 'orig'){ q.value = 'med'; q.onchange(); }
  render();
}
$('#tiles').onclick = e => { const b = e.target.closest('.tile'); if(!b) return; if(b.dataset.t === 'create') openMk(); else setTask(b.dataset.t); };
$('#outm').onchange = () => { built = null; sync(); };

const zipMode = () => $('#task').value === 'zip';
const runOnce = (G, list) => zipMode() ? zipOnce(G, list) : buildOnce(G, list);
async function zipOnce(G, list){                      // one pass of "photos and PDFs -> ZIP" (the target-size search calls this several times)
  if(typeof JSZip === 'undefined') throw new Error('The ZIP tool could not load. Please reinstall the app.');
  const Z = new JSZip(), used = new Set(), entries = [], N = list.length, pad = Math.max(3, String(N).length);
  for(let k = 0; k < N; k++){
    if(cancelFlag) throw new Cancelled();
    const it = list[k], m = it.cm ? Q[it.cm] : G;
    showProg(k / N * .9, N > 1 ? `File ${k + 1} of ${N}: ${it.file.name}` : it.file.name); await tick();
    let name = it.file.name, data = it.file, comp = 'STORE';
    try{
      if(it.kind === 'img'){
        if(m){
          const b = new Uint8Array(await it.file.arrayBuffer()), jpg = b[0] === 0xFF && b[1] === 0xD8, png = b[0] === 0x89 && b[1] === 0x50, sm = await shrink(it.file, m);
          if(!(jpg || png) || sm.bytes.length < it.file.size){ data = sm.bytes; name = name.replace(/\.[^.]+$/, '') + '.jpg'; }   // never bigger than the original
        }
      }else{
        comp = 'DEFLATE';
        if(m){ const doc = await PDFDocument.load(await it.file.arrayBuffer()); await squeeze(doc, m, null); const out = await doc.save(); if(out.length < it.file.size) data = out; }
      }
    }catch(e){ if(e instanceof Cancelled) throw e; throw new Error(`${it.file.name}: ${e.message || 'could not be added'}`); }
    name = name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_'); if($('#znum').checked) name = String(k + 1).padStart(pad, '0') + '-' + name;
    const dot = name.lastIndexOf('.'), base = dot > 0 ? name.slice(0, dot) : name, ext = dot > 0 ? name.slice(dot) : ''; let nm = name, c = 1;
    while(used.has(nm.toLowerCase())) nm = `${base} (${++c})${ext}`;
    used.add(nm.toLowerCase());
    Z.file(nm, data, {date:new Date(it.file.lastModified > 315532800000 ? it.file.lastModified : Date.now()), compression:comp});
    entries.push({name:nm, size:data.size !== undefined ? data.size : data.length});
  }
  showProg(.92, 'Making the ZIP file…'); await tick();
  const blob = await Z.generateAsync({type:'blob', streamFiles:true}, meta => showProg(.92 + meta.percent / 1250));
  return {bytes:null, blob, size:blob.size, zip:true, entries};
}
let lastZip = null;
function showZip(r){
  lastZip = r; $('#zpt').textContent = `${r.entries.length} file${r.entries.length === 1 ? '' : 's'}, ZIP size ${fmtSize(r.size)}`;
  $('#zpl').innerHTML = r.entries.map(e => `<div class="zr"><span>${esc(e.name)}</span><small>${fmtSize(e.size)}</small></div>`).join(''); $('#zpd').hidden = false;
}
$('#zps').onclick = () => { if(lastZip) save(lastZip); };
$('#zpx').onclick = () => { $('#zpd').hidden = true; };
async function fit(G, list, a, b, tag = ''){          // one PDF from `list`; with a target size, finds the best quality that fits
  const tgt = G && G.tune ? G.target : 0, w = b - a, rg = (x, y) => { pr = [a + x*w, a + y*w]; };
  if(!tgt){ curL = 1; rg(0, 1); pfx = tag; const r = await runOnce(G, list); r.tgt = 0; return r; }
  let lo = 0, hi = 1, best = null, last, L = 1;
  for(let p = 0; p < 6; p++){
    curL = L; rg(p/7, (p+1)/7); pfx = tag + `Pass ${p+1}: `; last = await runOnce(G, list);
    if(last.size <= tgt){ best = last; if(L >= 1 || last.size >= tgt * .92 || hi - lo < .03) break; lo = L; } else hi = L;
    L = p === 0 ? Math.pow(tgt / last.size, .8) : (lo + hi) / 2;
  }
  if(!best){ curL = 0; rg(6/7, 1); pfx = tag + 'Smallest: '; best = await runOnce(G, list); }
  best.tgt = tgt; return best;
}
const stem = f => f.name.replace(/\.[^.]+$/, '');
async function build(only){                           // only: a single file to save on its own
  if(!only && built) return built;
  const G = cfg(), list = only ? [only] : usable(), sep = $('#outm').value === 'sep'; cancelFlag = false; pr = [0, 1]; pfx = '';
  if(!list.length) throw new Error('Add at least one file for this task.');
  const total = fmtSize(list.reduce((a, i) => a + i.file.size, 0));
  if(only || !sep || list.length === 1){
    const r = await fit(G, list, 0, 1);
    if(only || sep) r.name = stem(list[0].file) + (only ? '-new' : '');
    r.msg = `Output size: ${fmtSize(r.size)}, from ${total} of files` + (r.tgt ? (r.size <= r.tgt ? ` (target ${fmtSize(r.tgt)})` : `. Target ${fmtSize(r.tgt)} could not be reached, this is the smallest result.`) : '');
    return only ? r : (built = r);
  }
  if(typeof JSZip === 'undefined') throw new Error('The ZIP tool could not load. Please reinstall the app.');
  const Z = new JSZip(), used = new Set(); let sum = 0, miss = 0;
  for(let k = 0; k < list.length; k++){
    const r = await fit(G, [list[k]], k / list.length, (k + 1) / list.length, `File ${k+1} of ${list.length}: `);
    let nm = stem(list[k].file) + '.pdf', c = 1; while(used.has(nm)) nm = `${stem(list[k].file)} (${++c}).pdf`;
    used.add(nm); Z.file(nm, r.bytes); sum += r.size; if(r.tgt && r.size > r.tgt) miss++;
  }
  pfx = ''; pr = [0, 1]; showProg(.98, 'Making the ZIP file…'); await tick();
  const blob = await Z.generateAsync({type:'blob', compression:'STORE'});
  return built = {bytes:null, blob, size:blob.size, zip:true, msg:`${list.length} PDFs, ${fmtSize(sum)} in total, from ${total} of files` + (miss ? `. ${miss} could not reach the target size.` : '')};
}
async function run(fn, only){
  if(busy) return; busy = true; $('#merge').disabled = $('#prev').disabled = true; $('#pw').hidden = false; showProg(0, 'Starting…');
  try{ const r = await build(only); pr = [0, 1]; pfx = ''; showProg(1, 'Done'); await fn(r); toast(r.msg); }
  catch(e){ toast(e instanceof Cancelled ? 'Export cancelled.' : e.message); }
  busy = false; $('#pw').hidden = true; render_status();
}
function render_status(){ const ok = usable().length; sync(); $('#st').textContent = ok ? `${ok} file${ok===1?'':'s'} ready` : 'No files yet'; $('#merge').disabled = $('#prev').disabled = !ok; }
function save(r){ const blob = r.blob;
  const fname = (r.name || $('#name').value.trim().replace(/\.(pdf|zip)$/i,'') || 'PDF Magic') + (r.zip ? '.zip' : '.pdf');
  if(NA){ nativeSend(blob, fname, 'save').then(m => toast(m || 'Saved.')).catch(() => toast('Could not save the file.')); return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = fname;
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
$('#merge').onclick = () => run(r => save(r));
$('#prev').onclick = () => run(r => r.zip ? showZip(r) : openViewer('Preview of merged PDF', r.bytes, {save:() => save(r)}));

/* ---------- page editor ---------- */
const docCache = new Map();
const getDoc = f => { if(!docCache.has(f)) docCache.set(f, f.arrayBuffer().then(b => pdfjsLib.getDocument({data:new Uint8Array(b)}).promise)); return docCache.get(f); };
function rotC(src, deg){
  if(!deg) return src;
  const c = document.createElement('canvas'), q = deg % 180; c.width = q ? src.height : src.width; c.height = q ? src.width : src.height;
  const g = c.getContext('2d'); g.translate(c.width/2, c.height/2); g.rotate(deg*Math.PI/180); g.drawImage(src, -src.width/2, -src.height/2); return c;
}
function textCanvas(text, W){                       // A4-shaped white page with wrapped text (any language)
  const c = document.createElement('canvas'); c.width = W; c.height = Math.round(W*1.41428);
  const g = c.getContext('2d'), sz = W*.0235, mg = W*.084; let y = mg;
  g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.fillStyle = '#000'; g.textBaseline = 'top'; g.font = `${sz}px Helvetica, Arial, sans-serif`;
  for(const para of text.split('\n')){
    let line = '';
    for(const w of para.split(' ')){ const t = line ? line+' '+w : w; if(g.measureText(t).width > W-2*mg && line){ g.fillText(line, mg, y); y += sz*1.5; line = w; } else line = t; }
    g.fillText(line, mg, y); y += sz*1.5;
  }
  return c;
}
async function pageThumb(d, w = 300){
  if(d.k === 'p'){
    const p = await (await getDoc(d.f)).getPage(d.n+1), rotation = (p.rotate + d.rot) % 360;
    const k = w / p.getViewport({scale:1, rotation}).width, v = p.getViewport({scale:k, rotation}), c = document.createElement('canvas');
    c.width = v.width; c.height = v.height; await p.render({canvasContext:c.getContext('2d'), viewport:v}).promise; return c;
  }
  let c;
  if(d.k === 'i'){
    const b = await createImageBitmap(d.f); c = document.createElement('canvas'); c.width = w; c.height = Math.round(w*b.height/b.width);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(b, 0, 0, c.width, c.height);
  }else c = textCanvas(d.k === 't' ? d.text : '', w);
  return rotC(c, d.rot);
}
const lazy = new IntersectionObserver(es => es.forEach(async e => {
  if(!e.isIntersecting) return; const im = e.target; lazy.unobserve(im); const d = im._d;
  try{ if(!d.u) d.u = (await pageThumb(d)).toDataURL('image/jpeg', .7); }catch(x){ d.u = ''; }
  if(im.isConnected) im.src = d.u;
}), {rootMargin:'500px'});
function cards(root, list, btns){
  root.innerHTML = list.map((d, i) => `<div class="cd${d._s ? ' sel' : ''}" data-i="${i}"><div class="im"><img alt=""><i>${i+1}</i>${(d.ov && d.ov.length) || d.crop ? '<em>edited</em>' : ''}</div>${typeof btns === 'function' ? btns(d) : btns}</div>`).join('');
  root.querySelectorAll('img').forEach((im, i) => { im._d = list[i]; if(list[i].u) im.src = list[i].u; else lazy.observe(im); });
}
const BTN = d => `<div class="ab"><button data-a="rot">Rotate</button><button data-a="rep">Replace</button><button data-a="ins">Insert</button><button data-a="l" aria-label="Move earlier">←</button><button data-a="r" aria-label="Move later">→</button><button data-a="del">Delete</button><button data-a="dup2">Copy</button><button data-a="mv" style="grid-column:span 2">Move to…</button>${d.k==='p'||d.k==='i'?`<button data-a="cq" style="grid-column:1/-1">${CQN[d.cm||'']}</button>`:''}${d.k==='p'||d.k==='b'||d.k==='t'?'<button data-a="ce" style="grid-column:1/-1">Edit content</button>':''}</div>`;
let ed = null, sh = null, pk = null;
const fresh = async it => Array.from({length:(await getDoc(it.file)).numPages}, (_, n) => ({k:'p', f:it.file, n, rot:0}));
function edRender(){
  const L = ed.list; $('#eg').classList.toggle('selmode', !!ed.sm); $('#esb').hidden = !ed.sm; $('#esel').classList.toggle('on', !!ed.sm); $('#esel').textContent = ed.sm ? 'Done selecting' : 'Select';
  if(L.length) cards($('#eg'), L, ed.sm ? '' : BTN); else $('#eg').innerHTML = '<p class="empty">No pages left. Tap Add page, or Reset to start over.</p>';
  $('#esn').textContent = `${L.filter(d => d._s).length} selected`;
}
async function openEditor(it){
  try{ ed = {it, list:it.pg || await fresh(it), dirty:!!it.pg}; }catch(e){ return toast('Could not open this PDF.'); }
  $('#et').textContent = it.file.name; $('#ed').hidden = false; edRender();
}
$('#ereset').onclick = async () => { ed.list = await fresh(ed.it); ed.it.pg = null; ed.dirty = false; edRender(); };
$('#eadd').onclick = () => openSheet('ins', ed.list.length);
$('#edone').onclick = async () => {
  const {it, list, dirty} = ed; ed = null; list.forEach(d => { delete d._s; }); $('#ed').hidden = true;
  if(dirty){ it.pg = list; try{ if(list.length) it.thumb = (await pageThumb(list[0], 140)).toDataURL('image/jpeg', .7); }catch(e){} }
  render();
};
$('#eg').onclick = e => {
  if(ed.sm){                                            // select mode: tap a page to pick it
    const cd = e.target.closest('.cd'); if(!cd) return; const d = ed.list[+cd.dataset.i]; d._s = !d._s; cd.classList.toggle('sel', !!d._s);
    $('#esn').textContent = `${ed.list.filter(x => x._s).length} selected`; return;
  }
  const b = e.target.closest('[data-a]'); if(!b) return;
  const i = +b.closest('.cd').dataset.i, L = ed.list, a = b.dataset.a;
  if(a === 'rot'){ L[i].rot = (L[i].rot + 90) % 360; L[i].u = null; }
  else if(a === 'del') L.splice(i, 1);
  else if(a === 'dup2') L.splice(i + 1, 0, cloneD(L[i]));
  else if(a === 'mv') return movePrompt([L[i]]);
  else if(a === 'cq'){ const ks = CQO.map(x => x[0]); L[i].cm = ks[(ks.indexOf(L[i].cm || '') + 1) % ks.length]; }
  else if(a === 'ce') return openCE(ed.list, i, ch => { if(ch) ed.dirty = true; edRender(); });
  else if(a === 'l' || a === 'r'){ const j = i + (a === 'l' ? -1 : 1); if(j < 0 || j >= L.length) return; [L[i], L[j]] = [L[j], L[i]]; }
  else return openSheet(a === 'rep' ? 'rep' : 'ins', a === 'rep' ? i : i + 1);
  ed.dirty = true; edRender();
};
function openSheet(mode, i){
  sh = {mode, i}; $('#sht').textContent = mode === 'rep' ? `Replace page ${i+1} with` : 'Add a page'; $('#tx').hidden = true; $('#sheet').hidden = false;
}
function apply(ds){
  ed.list.splice(sh.i, sh.mode === 'rep' ? 1 : 0, ...ds); ed.dirty = true;
  $('#sheet').hidden = $('#pk').hidden = true; edRender();
}
$('#sheet').onclick = e => {
  const s = e.target.dataset.s;
  if(!s){ if(e.target.id === 'sheet') $('#sheet').hidden = true; return; }
  if(s === 'x') $('#sheet').hidden = true;
  else if(s === 'blank') apply([{k:'b', rot:0}]);
  else if(s === 'text'){ $('#tx').hidden = false; $('#ta').focus(); }
  else if(s === 'txok'){ const t = $('#ta').value.trim(); if(!t) return toast('Type some text first.'); apply([{k:'t', text:t, rot:0}]); $('#ta').value = ''; }
  else if(s === 'img') $('#fi').click();
  else if(s === 'pdf') $('#fp').click();
};
$('#fi').onchange = async e => { const raw = [...e.target.files]; e.target.value = ''; const fs = await snap(raw); if(fs.length) apply(fs.map(f => ({k:'i', f, rot:0}))); };
$('#fp').onchange = async e => {
  const raw = e.target.files[0]; e.target.value = ''; if(!raw) return; const [f] = await snap([raw]); if(!f) return;
  try{ const n = (await getDoc(f)).numPages; pk = {list:Array.from({length:n}, (_, i) => ({k:'p', f, n:i, rot:0}))}; cards($('#pg2'), pk.list, ''); $('#pk').hidden = false; }
  catch(x){ toast('Could not read that PDF. Password-protected files are not supported.'); }
};
$('#pg2').onclick = e => { const c = e.target.closest('.cd'); if(c) apply([pk.list[+c.dataset.i]]); };
$('#pkall').onclick = () => apply(pk.list);
$('#pkx').onclick = () => $('#pk').hidden = true;

async function readFile(f){ try{ return await f.arrayBuffer(); }catch(e){ throw new Error(`"${f.name}" could not be read any more (the phone closed access to it). Remove it and pick it again.`); } }
async function addEdited(out, it, size, m, prog, shared){      // builds the PDF from the edited page list
  const docs = shared || new Map(), L = it.pg, cache = {};
  for(let i = 0; i < L.length; i++){
    if(cancelFlag) throw new Cancelled(); prog(i / L.length); await tick();
    const d = L[i]; let pg;
    if(d.k === 'p'){
      let src = docs.get(d.f); if(!src){ src = await PDFDocument.load(await readFile(d.f)); docs.set(d.f, src); }
      const pm = d.cm ? Q[d.cm] : m; if(pm) await squeeze(src, pm, d.n);     // page setting beats file setting
      pg = out.addPage((await out.copyPages(src, [d.n]))[0]);
    }else if(d.k === 'i'){ await addImage(out, d.f, await readFile(d.f), size, d.cm ? Q[d.cm] : m); pg = out.getPage(out.getPageCount() - 1); }
    else{
      pg = out.addPage([595.28, 841.89]);
      if(d.k === 't'){
        const png = await new Promise(r => textCanvas(d.text, 1800).toBlob(r, 'image/png'));
        pg.drawImage(await out.embedPng(new Uint8Array(await png.arrayBuffer())), {x:0, y:0, width:595.28, height:841.89});
      }
    }
    if(d.k !== 'i') await applyOv(out, pg, d, cache);
    if(d.rot) pg.setRotation(degrees((pg.getRotation().angle + d.rot) % 360));
  }
}

/* ---------- page content editor: text, pictures, shapes, cover, crop ---------- */
let CE = null, zoomT;
const FAM = {Helvetica:"Helvetica, Arial, sans-serif", Times:"'Times New Roman', Times, serif", Courier:"'Courier New', Courier, monospace"};
const FN = {Helvetica:['Helvetica', 'HelveticaBold', 'HelveticaOblique', 'HelveticaBoldOblique'], Times:['TimesRoman', 'TimesRomanBold', 'TimesRomanItalic', 'TimesRomanBoldItalic'], Courier:['Courier', 'CourierBold', 'CourierOblique', 'CourierBoldOblique']};
const HINT = {sel:'Tap an item to change it. Drag to move it. Drag a corner dot to resize it.', text:'Tap the page where the text should go.', r:'Drag on the page to draw a box.', e:'Drag on the page to draw a circle or oval.', l:'Drag on the page to draw a line.', a:'Drag from the tail to the point of the arrow.', w:'Drag a box over text or a picture to hide it. The original is still inside the file.', retype:'Drag a box over the text to replace. It gets hidden, then you type the new text.', crop:'Drag a box around the part of the page to keep.', hl:'Drag along the text to highlight it.', ul:'Drag along the text to underline it.', st:'Drag along the text to strike it out.', pen:'Draw with your finger.', pencil:'Draw thin pencil lines with your finger.', er:'Drag over anything you added to remove it.', note:'Tap the page where the note should go.', stamp:'Tap a stamp to place it. Then move or resize it.'};
const NOPHOTO = 'Photo pages cannot be marked up. Create a PDF from the photos first, then edit that PDF.';
const mctx = document.createElement('canvas').getContext('2d');
const fontCss = (o, sz) => `${o.i ? 'italic ' : ''}${o.b ? 'bold ' : ''}${sz}px ${FAM[o.font]}`;
const tlines = o => o.text.replace(/\r/g, '').split('\n');
const lineW = (o, l) => { mctx.font = fontCss(o, o.size); return mctx.measureText(l || ' ').width; };
const tsize = o => ({w:Math.max(...tlines(o).map(l => lineW(o, l))), h:tlines(o).length * o.size * 1.2});
function bbox(o){
  if(o.k === 't') return {x:o.x, y:o.y, ...tsize(o)};
  if(o.k === 'l' || o.k === 'a') return {x:Math.min(o.x1, o.x2), y:Math.min(o.y1, o.y2), w:Math.abs(o.x2 - o.x1), h:Math.abs(o.y2 - o.y1)};
  if(o.k === 'n') return {x:o.x, y:o.y, w:24, h:24};
  const R = o.rects || (o.pts && o.pts.map(q => [q[0], q[1], 0, 0]));
  if(R){ const x0 = Math.min(...R.map(r => r[0])), y0 = Math.min(...R.map(r => r[1])), x1 = Math.max(...R.map(r => r[0] + r[2])), y1 = Math.max(...R.map(r => r[1] + r[3])); return {x:x0, y:y0, w:x1 - x0, h:y1 - y0}; }
  return {x:o.x, y:o.y, w:o.w, h:o.h};
}
const ahead = o => { const a = Math.atan2(o.y2 - o.y1, o.x2 - o.x1), L = 8 + o.lw * 3; return [-.45, .45].map(d => [o.x2 - L * Math.cos(a + d), o.y2 - L * Math.sin(a + d)]); };
const hexRgb = h => { const n = parseInt(h.slice(1), 16); return PDFLib.rgb(((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255); };
const hs = o => {
  if(['hl', 'ul', 'st', 's', 'n'].includes(o.k)) return [];
  if(o.k === 'l' || o.k === 'a') return [{n:'p1', x:o.x1, y:o.y1}, {n:'p2', x:o.x2, y:o.y2}];
  const b = bbox(o); if(o.k === 't') return [{n:'se', x:b.x + b.w, y:b.y + b.h}];
  return [{n:'nw', x:b.x, y:b.y}, {n:'ne', x:b.x + b.w, y:b.y}, {n:'sw', x:b.x, y:b.y + b.h}, {n:'se', x:b.x + b.w, y:b.y + b.h}];
};
const segD = (p, o) => { const dx = o.x2 - o.x1, dy = o.y2 - o.y1, l2 = dx*dx + dy*dy || 1, t = Math.max(0, Math.min(1, ((p.x - o.x1)*dx + (p.y - o.y1)*dy) / l2)); return Math.hypot(p.x - o.x1 - t*dx, p.y - o.y1 - t*dy); };
const hit = (o, p) => { const r = 8 / CE.sc; if(o.k === 'l' || o.k === 'a') return segD(p, o) <= r + o.lw;
  if(o.k === 's') return o.pts.some((q, i) => { const n = o.pts[i + 1] || q; return segD(p, {x1:q[0], y1:q[1], x2:n[0], y2:n[1]}) <= r + o.lw; });
  if(o.rects) return o.rects.some(q => p.x >= q[0] - r && p.x <= q[0] + q[2] + r && p.y >= q[1] - r && p.y <= q[1] + q[3] + r);
  const b = bbox(o); return p.x >= b.x - r && p.x <= b.x + b.w + r && p.y >= b.y - r && p.y <= b.y + b.h + r; };
const shift = (o, dx, dy) => {
  if(o.k === 'l' || o.k === 'a'){ o.x1 += dx; o.x2 += dx; o.y1 += dy; o.y2 += dy; }
  else if(o.rects) o.rects = o.rects.map(r => [r[0] + dx, r[1] + dy, r[2], r[3]]);
  else if(o.pts) o.pts = o.pts.map(q => [q[0] + dx, q[1] + dy]);
  else { o.x += dx; o.y += dy; }
};
const shapeOf = (t, a, b) => {
  const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y), w = Math.abs(b.x - a.x), h = Math.abs(b.y - a.y);
  if(t === 'l' || t === 'a') return {k:t, x1:a.x, y1:a.y, x2:b.x, y2:b.y, sc:'#e5484d', lw:3};
  if(t === 'w' || t === 'retype') return {k:'w', x, y, w, h, fc:'#ffffff'};
  if(t === 'crop') return {k:'c', x, y, w, h};
  return {k:t, x, y, w, h, sc:'#e5484d', fc:'', lw:3};
};
function svgOf(o){
  const st = `stroke="${o.sc || 'none'}" stroke-width="${o.sc ? o.lw : 0}"`, fl = `fill="${o.fc || 'none'}"`;
  if(o.k === 'hl') return o.rects.map(r => `<rect x="${r[0]}" y="${r[1]}" width="${r[2]}" height="${r[3]}" fill="${o.c}" fill-opacity=".4"/>`).join('');
  if(o.k === 'ul' || o.k === 'st') return o.rects.map(r => { const y = r[1] + (o.k === 'ul' ? r[3] * 1.08 : r[3] * .45); return `<line x1="${r[0]}" y1="${y}" x2="${r[0] + r[2]}" y2="${y}" stroke="${o.c}" stroke-width="${Math.max(1, r[3] * .07)}"/>`; }).join('');
  if(o.k === 's') return `<polyline points="${o.pts.map(q => q.join(',')).join(' ')}" fill="none" stroke="${o.c}" stroke-width="${o.lw}" stroke-linecap="round" stroke-linejoin="round"/>`;
  if(o.k === 'n') return `<rect x="${o.x}" y="${o.y}" width="24" height="24" rx="3" fill="${o.c}" stroke="#b8860b" stroke-width="1"/><path d="M${o.x + 5} ${o.y + 8}h14M${o.x + 5} ${o.y + 13}h14M${o.x + 5} ${o.y + 18}h9" stroke="#8a6d00" stroke-width="1.5" fill="none"/>`;
  if(o.k === 't' && (o.bg || o.bd)){ const b = tsize(o), pd = o.size * .3; return `<rect x="${o.x - pd}" y="${o.y - pd * .6}" width="${b.w + 2 * pd}" height="${b.h + 1.2 * pd}" rx="${o.size * .15}" fill="${o.bg || 'none'}" stroke="${o.bd ? o.c : 'none'}" stroke-width="${o.size * .08}"/>` + svgOf({...o, bg:'', bd:false}); }
  if(o.k === 'w') return `<rect x="${o.x}" y="${o.y}" width="${o.w}" height="${o.h}" fill="${o.fc}"/>`;
  if(o.k === 'r') return `<rect x="${o.x}" y="${o.y}" width="${o.w}" height="${o.h}" ${fl} ${st}/>`;
  if(o.k === 'e') return `<ellipse cx="${o.x + o.w/2}" cy="${o.y + o.h/2}" rx="${o.w/2}" ry="${o.h/2}" ${fl} ${st}/>`;
  if(o.k === 'c') return `<rect x="${o.x}" y="${o.y}" width="${o.w}" height="${o.h}" fill="none" stroke="#5f6fee" stroke-width="${2 / CE.sc}" stroke-dasharray="${8 / CE.sc} ${5 / CE.sc}"/>`;
  if(o.k === 'i') return `<image href="${o._u}" x="${o.x}" y="${o.y}" width="${o.w}" height="${o.h}" preserveAspectRatio="none"/>`;
  if(o.k === 'l' || o.k === 'a'){
    const ln = (a, b, c, d) => `<line x1="${a}" y1="${b}" x2="${c}" y2="${d}" ${st} stroke-linecap="round"/>`;
    return ln(o.x1, o.y1, o.x2, o.y2) + (o.k === 'a' ? ahead(o).map(q => ln(o.x2, o.y2, q[0], q[1])).join('') : '');
  }
  return tlines(o).map((l, n) => {
    const by = o.y + o.size * .95 + n * o.size * 1.2;
    return `<text x="${o.x}" y="${by}" font-size="${o.size}" fill="${o.c}" font-family="${FAM[o.font]}" font-weight="${o.b ? 700 : 400}" font-style="${o.i ? 'italic' : 'normal'}" style="white-space:pre">${esc(l)}</text>`
      + (o.u && l ? `<line x1="${o.x}" x2="${o.x + lineW(o, l)}" y1="${by + o.size * .12}" y2="${by + o.size * .12}" stroke="${o.c}" stroke-width="${o.size * .06}"/>` : '');
  }).join('');
}
function drawCE(){
  const c = CE; if(!c) return; const d = c.d, k = 1 / c.sc; let h = (d.ov || []).map(svgOf).join('');
  if(d.crop){ const q = d.crop; h += `<path fill-rule="evenodd" fill="rgba(20,25,50,.45)" d="M0 0H${c.W}V${c.H}H0Z M${q.x} ${q.y}V${q.y + q.h}H${q.x + q.w}V${q.y}Z"/><rect x="${q.x}" y="${q.y}" width="${q.w}" height="${q.h}" fill="none" stroke="#5f6fee" stroke-width="${2*k}"/>`; }
  if(c.draft) h += svgOf(c.draft);
  if(c.sel && c.tool === 'sel'){
    const b = bbox(c.sel); h += `<rect x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" fill="none" stroke="#5f6fee" stroke-width="${1.5*k}" stroke-dasharray="${5*k} ${4*k}"/>`;
    h += hs(c.sel).map(q => `<circle cx="${q.x}" cy="${q.y}" r="${8*k}" fill="#fff" stroke="#5f6fee" stroke-width="${2*k}"/>`).join('');
  }
  $('#cs').innerHTML = h;
}
function layoutCE(){
  const c = CE; if(!c) return; const w0 = $('#cw').clientWidth - 24, h0 = $('#cw').clientHeight - 24;
  c.sc = Math.min(w0 / c.W, h0 / c.H) * c.zoom; const w = c.W * c.sc, h = c.H * c.sc;
  for(const e of [$('#cbox'), $('#cc')]){ e.style.width = w + 'px'; e.style.height = h + 'px'; }
  $('#cs').setAttribute('viewBox', `0 0 ${c.W} ${c.H}`); $('#cs').setAttribute('preserveAspectRatio', 'none'); drawCE();
}
async function renderBase(){
  const c = CE; if(!c) return; const tk = c.rt = (c.rt || 0) + 1, d = c.d, cv = $('#cc'); let px = Math.min(devicePixelRatio || 1, 2) * c.sc;
  const area = c.W * c.H * px * px; if(area > 16e6) px *= Math.sqrt(16e6 / area);
  if(d.k === 'p'){
    try{
      const p = await (await getDoc(d.f)).getPage(d.n + 1); if(CE !== c || tk !== c.rt) return;
      if(c.task){ try{ c.task.cancel(); }catch(e){} }
      const vp = p.getViewport({scale:px}); cv.width = vp.width; cv.height = vp.height; c.task = p.render({canvasContext:cv.getContext('2d'), viewport:vp}); await c.task.promise;
    }catch(e){}
  }else{
    const t = d.k === 't' ? textCanvas(d.text, Math.round(c.W * px)) : null; cv.width = t ? t.width : Math.round(c.W * px); cv.height = t ? t.height : Math.round(c.H * px);
    const g = cv.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height); if(t) g.drawImage(t, 0, 0);
  }
}
async function loadCE(i){
  const c = CE; c.i = i; const d = c.d = c.L[i]; c.sel = null; c.zoom = 1; c.drag = null; c.draft = null; c.ok = d.k !== 'i'; c.tool = 'sel';
  $('#ct').textContent = `Page ${i + 1} of ${c.L.length}`;
  if(d.k === 'p'){
    try{ const v = (await (await getDoc(d.f)).getPage(d.n + 1)).getViewport({scale:1}); if(CE !== c || c.d !== d) return; c.W = v.width; c.H = v.height; }
    catch(e){ toast('Could not open this page.'); c.W = 595.28; c.H = 841.89; }
  }else{ c.W = 595.28; c.H = 841.89; }
  if(c.ok){ d.ov = d.ov || []; d.ed = {w:c.W, h:c.H}; c.items = null; loadItems(c, d); }
  setTool('sel'); layoutCE(); renderBase();
}
function openCE(list, i, done){ CE = {L:list, done, ch:false, cfg:{pen:{c:'#2b3350', lw:3}, pencil:{c:'#555555', lw:2}, hl:{c:'#ffe94d'}, ul:{c:'#e5484d'}, st:{c:'#e5484d'}}}; $('#ce').hidden = false; loadCE(i); }
async function openItemCE(it){
  let list; try{ list = it.pg || await fresh(it); }catch(e){ return toast('Could not open this PDF.'); }
  openCE(list, 0, ch => { if(ch){ it.pg = list; render(); } });
}
function setTool(t){
  const c = CE; if(!c) return; if(t !== 'sel' && !c.ok) return toast(NOPHOTO);
  if(t !== 'sel') c.sel = null;
  if(['hl', 'ul', 'st'].includes(t) && c.d.k !== 'p') toast('This page has no real text to mark. Use Box, Pen or Cover instead.');
  c.tool = t; c.draft = null; document.querySelectorAll('#ctl [data-c]').forEach(b => b.classList.toggle('on', b.dataset.c === t)); props(); drawCE();
}
const lwSel = (o, k = 'lw') => `<select data-p="${k}">${[1, 2, 3, 5, 8, 12].map(n => `<option${o.lw === n ? ' selected' : ''}>${n}</option>`).join('')}</select>`;
const col = (k, v, label) => `<label class="pc">${label}<input type="color" data-p="${k}" value="${v || '#ffffff'}"></label>`;
const STAMPS = [['APPROVED', '#2e9e5b'], ['REJECTED', '#e5484d'], ['DRAFT', '#5f6fee'], ['CONFIDENTIAL', '#c2410c'], ['PAID', '#2e9e5b'], ['URGENT', '#e5484d'], ['COPY', '#7a84a3']];
function props(){
  const c = CE, p = $('#pp'); if(!c) return; const o = c.sel;
  if(!c.ok){ p.innerHTML = '<span class="hn">This is a photo page. To mark it up, first create a PDF from your photos, then edit that PDF.</span>'; return; }
  if(!o){
    const t = c.cfg[c.tool], crop = c.d.crop ? '<button class="d" data-p="uncrop">Remove crop</button>' : '';
    if(c.tool === 'stamp') p.innerHTML = STAMPS.map(([n, k], i) => `<button data-p="stamp" data-i="${i}" style="color:${k}">${n}</button>`).join('') + '<button data-p="stampx">Custom…</button>';
    else p.innerHTML = `<span class="hn">${HINT[c.tool]}</span>` + (t ? col('tc', t.c, 'Color') + (t.lw ? lwSel(t, 'tw') : '') : '') + crop;
    return;
  }
  let h = '';
  if(o.k === 't') h = `<select data-p="font">${Object.keys(FAM).map(f => `<option${o.font === f ? ' selected' : ''}>${f}</option>`).join('')}</select><button data-p="sm">A−</button><b>${Math.round(o.size)}</b><button data-p="sp">A+</button>${col('c', o.c, 'Color')}<button data-p="b" class="${o.b ? 'on' : ''}"><b>B</b></button><button data-p="i" class="${o.i ? 'on' : ''}"><i>I</i></button><button data-p="u" class="${o.u ? 'on' : ''}"><u>U</u></button><button data-p="bd" class="${o.bd ? 'on' : ''}">Border</button><button data-p="bg" class="${o.bg ? 'on' : ''}">Fill</button><button data-p="edit">Edit text</button>`;
  else if(o.k === 'r' || o.k === 'e') h = col('sc', o.sc, 'Line') + col('fc', o.fc, 'Fill') + `<button data-p="nofill" class="${o.fc ? '' : 'on'}">No fill</button>` + lwSel(o);
  else if(o.k === 'l' || o.k === 'a') h = col('sc', o.sc, 'Color') + lwSel(o);
  else if(o.k === 'w') h = col('fc', o.fc, 'Cover color');
  else if(o.k === 'i') h = '<button data-p="rep">Replace picture</button>';
  else if(o.k === 'hl' || o.k === 'ul' || o.k === 'st') h = col('c', o.c, 'Color');
  else if(o.k === 's') h = col('c', o.c, 'Color') + lwSel(o);
  else if(o.k === 'n') h = col('c', o.c, 'Color') + '<button data-p="edit">Edit note</button>';
  p.innerHTML = h + '<button data-p="dup">Copy</button><button class="d" data-p="del">Delete</button>';
}
const onProp = e => {
  const c = CE, o = c && c.sel, k = e.target.dataset.p; if(!c || !k) return; const t = c.cfg[c.tool];
  if(!o){ if(t && k === 'tc') t.c = e.target.value; else if(t && k === 'tw') t.lw = +e.target.value; return; }
  if(e.target.type === 'color') o[k] = e.target.value; else if(k === 'font') o.font = e.target.value; else if(k === 'lw') o.lw = +e.target.value; else return;
  c.ch = true; drawCE();
};
$('#pp').addEventListener('input', onProp); $('#pp').addEventListener('change', onProp);
$('#pp').addEventListener('click', e => {
  const b = e.target.closest('button[data-p]'), c = CE; if(!b || !c) return; const o = c.sel, k = b.dataset.p, ov = c.d.ov;
  if(k === 'stamp'){ const [n, cl] = STAMPS[+b.dataset.i]; return addStamp(n, cl); }
  if(k === 'stampx') return addStamp('', '#5f6fee', true);
  if(k === 'uncrop') delete c.d.crop;
  else if(!o) return;
  else if(k === 'sm' || k === 'sp') o.size = Math.max(6, Math.min(200, Math.round(o.size * (k === 'sp' ? 1.15 : .87))));
  else if(k === 'b' || k === 'i' || k === 'u' || k === 'bd') o[k] = !o[k];
  else if(k === 'bg') o.bg = o.bg ? '' : '#fff3a8';
  else if(k === 'nofill') o.fc = o.fc ? '' : '#ffe27a';
  else if(k === 'edit') return editText(o);
  else if(k === 'rep'){ c.rep = true; return $('#fci').click(); }
  else if(k === 'dup'){ const n = {...o}; shift(n, 14, 14); ov.push(n); c.sel = n; }
  else if(k === 'del'){ ov.splice(ov.indexOf(o), 1); c.sel = null; }
  c.ch = true; drawCE(); props();
});
function addStamp(text, color, custom){
  const c = CE, o = {k:'t', x:0, y:0, text, size:28, font:'Helvetica', b:true, i:false, u:false, c:color, bd:true};
  if(text){ const b = tsize(o); o.x = (c.W - b.w) / 2; o.y = (c.H - b.h) / 2; } else { o.x = c.W * .25; o.y = c.H * .4; }
  c.d.ov.push(o); c.sel = o; c.ch = true; setTool('sel'); if(custom) editText(o, true);
}
async function loadItems(c, d){                       // text boxes of the page, used by Highlight / Underline / Strikeout
  if(d.k !== 'p') return c.items = [];
  try{
    const p = await (await getDoc(d.f)).getPage(d.n + 1), tc = await p.getTextContent(), vp = p.getViewport({scale:1}); if(CE !== c || c.d !== d) return;
    c.items = tc.items.map((it, i) => it.str && it.str.trim() ? rects(tc, vp, {parts:[{i, a:0, b:it.str.length}]})[0] : null).filter(Boolean);
  }catch(e){ c.items = []; }
}
function markDraft(t, a, b){
  const c = CE, q = {x:Math.min(a.x, b.x), y:Math.min(a.y, b.y), w:Math.abs(b.x - a.x), h:Math.abs(b.y - a.y)}, out = [];
  for(const r of c.items || []){
    if(r[0] > q.x + q.w || r[0] + r[2] < q.x || r[1] > q.y + q.h || r[1] + r[3] < q.y) continue;
    if(q.h <= r[3] * 1.6){ const x0 = Math.max(r[0], q.x), x1 = Math.min(r[0] + r[2], q.x + q.w); if(x1 > x0) out.push([x0, r[1], x1 - x0, r[3]]); }   // one line: only the part you dragged over
    else out.push(r.slice());
  }
  return out.length ? {k:t, rects:out, c:c.cfg[t].c} : null;
}
function erase(p){ const c = CE, ov = c.d.ov; for(let i = ov.length - 1; i >= 0; i--) if(hit(ov[i], p)){ ov.splice(i, 1); c.ch = true; c.sel = null; } drawCE(); }
function editText(o, isNew, cover){ const t = $('#tdlg'); t._o = o; t._n = !!isNew; $('#tdt').value = o.text; t.hidden = false; setTimeout(() => $('#tdt').focus(), 60); }
function dropText(){ const c = CE, o = $('#tdlg')._o; if(!c) return; const i = c.d.ov.indexOf(o); if(i >= 0) c.d.ov.splice(i, 1); c.sel = null; drawCE(); props(); }
$('#tdok').onclick = () => { const t = $('#tdlg'), v = $('#tdt').value; t.hidden = true; if(!v.trim()) return dropText(); t._o.text = v; CE.ch = true; drawCE(); props(); };
$('#tdno').onclick = () => { $('#tdlg').hidden = true; if($('#tdlg')._n) dropText(); };
async function addPic(f){
  const c = CE, rep = c.rep && c.sel && c.sel.k === 'i' ? c.sel : null; c.rep = false; let bmp;
  try{ bmp = await createImageBitmap(f); }catch(e){ return toast('That picture type is not supported here.'); }
  const nw = bmp.width, nh = bmp.height; if(bmp.close) bmp.close(); const u = URL.createObjectURL(f);
  if(rep){ rep.f = f; rep._u = u; rep.h = rep.w * nh / nw; }
  else{ const w = Math.min(c.W * .5, nw), h = w * nh / nw, o = {k:'i', f, _u:u, x:(c.W - w) / 2, y:(c.H - h) / 2, w, h}; c.d.ov.push(o); c.sel = o; }
  c.ch = true; drawCE(); props();
}
$('#fci').onchange = async e => { const raw = e.target.files[0]; e.target.value = ''; if(!raw || !CE) return; const [f] = await snap([raw]); if(f && CE) addPic(f); };
$('#ctl').addEventListener('click', e => {
  const b = e.target.closest('[data-c]'), c = CE; if(!b || !c) return; const k = b.dataset.c;
  if(k === 'zi' || k === 'zo'){ c.zoom = Math.max(1, Math.min(5, c.zoom * (k === 'zi' ? 1.3 : 1 / 1.3))); layoutCE(); clearTimeout(zoomT); zoomT = setTimeout(renderBase, 250); }
  else if(k === 'img'){ if(!c.ok) return toast(NOPHOTO); c.rep = false; $('#fci').click(); }
  else setTool(k);
});
const ptOf = e => { const r = $('#cs').getBoundingClientRect(); return {x:(e.clientX - r.left) / CE.sc, y:(e.clientY - r.top) / CE.sc}; };
$('#cs').addEventListener('pointerdown', e => {
  const c = CE; if(!c) return; e.preventDefault(); if(!c.ok) return toast(NOPHOTO);
  const p = ptOf(e), ov = c.d.ov; $('#cs').setPointerCapture(e.pointerId);
  if(c.tool === 'sel'){
    const h = c.sel && hs(c.sel).find(q => Math.hypot(p.x - q.x, p.y - q.y) <= 14 / c.sc);
    if(h) c.drag = {t:h.n, b:bbox(c.sel), s0:c.sel.size, o:c.sel};
    else{
      const o = [...ov].reverse().find(x => hit(x, p)); c.sel = o || null;
      c.drag = o ? {t:'move', p0:p, snap:{...o}, o} : {t:'pan', cx:e.clientX, cy:e.clientY, sl:$('#cw').scrollLeft, st:$('#cw').scrollTop}; props();
    }
    drawCE();
  }else if(c.tool === 'text'){
    const o = {k:'t', x:p.x, y:p.y, text:'', size:18, font:'Helvetica', b:false, i:false, u:false, c:'#000000'}; ov.push(o); c.sel = o; c.ch = true; setTool('sel'); editText(o, true);
  }else if(c.tool === 'note'){
    const o = {k:'n', x:p.x, y:p.y, text:'', c:'#ffe27a'}; ov.push(o); c.sel = o; c.ch = true; setTool('sel'); editText(o, true);
  }else if(c.tool === 'pen' || c.tool === 'pencil'){
    const g = c.cfg[c.tool]; c.draft = {k:'s', pts:[[p.x, p.y]], c:g.c, lw:g.lw}; c.drag = {t:'ink'}; drawCE();
  }else if(c.tool === 'er'){ c.drag = {t:'erase'}; erase(p); }
  else c.drag = {t:'draw', p0:p};
});
$('#cs').addEventListener('pointermove', e => {
  const c = CE, d = c && c.drag; if(!d) return; const p = ptOf(e);
  if(d.t === 'pan'){ $('#cw').scrollLeft = d.sl - (e.clientX - d.cx); $('#cw').scrollTop = d.st - (e.clientY - d.cy); return; }
  if(d.t === 'ink'){ const q = c.draft.pts[c.draft.pts.length - 1]; if(Math.hypot(p.x - q[0], p.y - q[1]) >= 1){ c.draft.pts.push([Math.round(p.x * 10) / 10, Math.round(p.y * 10) / 10]); drawCE(); } return; }
  if(d.t === 'erase'){ erase(p); return; }
  if(d.t === 'move'){ Object.assign(d.o, d.snap); shift(d.o, p.x - d.p0.x, p.y - d.p0.y); d.dirty = true; }
  else if(d.t === 'draw') c.draft = ['hl', 'ul', 'st'].includes(c.tool) ? markDraft(c.tool, d.p0, p) : shapeOf(c.tool, d.p0, p);
  else if(d.t === 'p1' || d.t === 'p2'){ const n = d.t === 'p1' ? ['x1', 'y1'] : ['x2', 'y2']; d.o[n[0]] = p.x; d.o[n[1]] = p.y; d.dirty = true; }
  else{
    const o = d.o, b = d.b;
    if(o.k === 't') o.size = Math.max(6, Math.min(200, d.s0 * (p.x - b.x) / (b.w || 1)));
    else{
      const ox = d.t.includes('w') ? b.x + b.w : b.x, oy = d.t.includes('n') ? b.y + b.h : b.y;
      const w = Math.max(8, Math.abs(p.x - ox)), h = o.k === 'i' ? w * b.h / b.w : Math.max(8, Math.abs(p.y - oy));
      o.x = p.x < ox ? ox - w : ox; o.y = p.y < oy ? oy - h : oy; o.w = w; o.h = h;
    }
    d.dirty = true;
  }
  drawCE();
});
function endDrag(){
  const c = CE, d = c && c.drag; if(!d) return; c.drag = null;
  if(d.t === 'ink'){
    const st = c.draft; c.draft = null;
    if(st){ if(st.pts.length === 1) st.pts.push([st.pts[0][0] + .1, st.pts[0][1]]); c.d.ov.push(st); c.ch = true; }
  }else if(d.t === 'draw'){
    const dr = c.draft, t = c.tool; c.draft = null;
    const ok = dr && (dr.rects ? dr.rects.length : (dr.k === 'l' || dr.k === 'a') ? Math.hypot(dr.x2 - dr.x1, dr.y2 - dr.y1) > 6 : dr.w > 4 && dr.h > 4);
    if(ok) finishDraw(dr, t); else if(!['hl', 'ul', 'st'].includes(t)) setTool('sel');
  }else if(d.dirty){ c.ch = true; props(); }
  drawCE();
}
$('#cs').addEventListener('pointerup', endDrag); $('#cs').addEventListener('pointercancel', endDrag);
function finishDraw(dr, t){
  const c = CE, ov = c.d.ov;
  if(dr.rects){ ov.push(dr); c.ch = true; return; }
  if(t === 'crop'){ c.d.crop = {x:dr.x, y:dr.y, w:dr.w, h:dr.h}; c.ch = true; return setTool('sel'); }
  if(t === 'retype'){
    const tx = {k:'t', x:dr.x, y:dr.y, text:'', size:Math.max(8, Math.min(60, dr.h * .8)), font:'Helvetica', b:false, i:false, u:false, c:'#000000'};
    ov.push(dr, tx); c.sel = tx; c.ch = true; setTool('sel'); return editText(tx, true);
  }
  ov.push(dr); c.sel = dr; c.ch = true; setTool('sel');
}
$('#cpv').onclick = () => { if(CE && CE.i > 0) loadCE(CE.i - 1); };
$('#cnx').onclick = () => { if(CE && CE.i < CE.L.length - 1) loadCE(CE.i + 1); };
$('#cdone').onclick = () => { const c = CE; CE = null; $('#ce').hidden = true; $('#tdlg').hidden = true; c.done(c.ch); };
let ceT; addEventListener('resize', () => { clearTimeout(ceT); ceT = setTimeout(() => { if(CE && !$('#ce').hidden){ layoutCE(); renderBase(); } }, 250); });

async function drawTextObj(doc, pg, o, X, Y, kx, ky, cache){
  const fname = FN[o.font][(o.b ? 1 : 0) + (o.i ? 2 : 0)], font = cache[fname] || (cache[fname] = await doc.embedFont(PDFLib.StandardFonts[fname]));
  const col = hexRgb(o.c), sz = o.size * kx, L = tlines(o).map(l => l.replace(/\t/g, '    ')); let ok = true;
  const box = (bw, bh) => {                           // border and fill behind a text box or stamp
    if(!o.bg && !o.bd) return; const pd = o.size * .3;
    pg.drawRectangle({x:X(o.x - pd), y:Y(o.y - pd * .6 + bh + 1.2 * pd), width:(bw + 2 * pd) * kx, height:(bh + 1.2 * pd) * ky, color:o.bg ? hexRgb(o.bg) : undefined, borderColor:o.bd ? col : undefined, borderWidth:o.bd ? o.size * .08 : 0});
  };
  try{ L.forEach(l => font.widthOfTextAtSize(l || ' ', sz)); }catch(e){ ok = false; }
  if(ok){
    box(Math.max(...L.map(l => font.widthOfTextAtSize(l || ' ', o.size))), L.length * o.size * 1.2);
    L.forEach((l, n) => {
      const by = o.y + o.size * .95 + n * o.size * 1.2; if(!l) return;
      pg.drawText(l, {x:X(o.x), y:Y(by), size:sz, font, color:col});
      if(o.u) pg.drawLine({start:{x:X(o.x), y:Y(by + o.size * .12)}, end:{x:X(o.x) + font.widthOfTextAtSize(l, sz), y:Y(by + o.size * .12)}, thickness:sz * .06, color:col});
    });
    return;
  }
  const S = 3, b = tsize(o), c = document.createElement('canvas'), w = b.w + 2, h = b.h + 2; c.width = Math.ceil(w * S); c.height = Math.ceil(h * S);
  const g = c.getContext('2d'); g.font = fontCss(o, o.size * S); g.fillStyle = g.strokeStyle = o.c; g.lineWidth = o.size * S * .06;     // other alphabets: draw the text as a picture
  tlines(o).forEach((l, n) => { const by = (o.size * .95 + n * o.size * 1.2) * S; g.fillText(l, 0, by); if(o.u && l){ g.beginPath(); g.moveTo(0, by + o.size * S * .12); g.lineTo(lineW(o, l) * S, by + o.size * S * .12); g.stroke(); } });
  const png = await new Promise(r => c.toBlob(r, 'image/png'));
  box(b.w, b.h);
  pg.drawImage(await doc.embedPng(new Uint8Array(await png.arrayBuffer())), {x:X(o.x), y:Y(o.y + h), width:w * kx, height:h * ky});
}
async function applyOv(doc, pg, d, cache){             // draws the page's added items, then crops
  const ov = d.ov || [], cr = d.crop; if(!ov.length && !cr) return;
  const R = ((Math.round(pg.getRotation().angle / 90) * 90) % 360 + 360) % 360, B = pg.getCropBox(), W = B.width, H = B.height;
  const dW = R % 180 ? H : W, dH = R % 180 ? W : H, kx = d.ed ? dW / d.ed.w : 1, ky = d.ed ? dH / d.ed.h : 1;
  const M = {0:[1, 0, 0, 1, B.x, B.y], 90:[0, 1, -1, 0, B.x + W, B.y], 180:[-1, 0, 0, -1, B.x + W, B.y + H], 270:[0, -1, 1, 0, B.x, B.y + H]}[R];
  const X = v => v * kx, Y = v => dH - v * ky, fill = h => h ? hexRgb(h) : undefined, f = (x, y) => [M[0] * x + M[2] * y + M[4], M[1] * x + M[3] * y + M[5]];
  pg.pushOperators(PDFLib.pushGraphicsState(), PDFLib.concatTransformationMatrix(...M));     // draw in "upright page" coordinates, whatever the page's own rotation
  for(const o of ov){
    if(o.k === 'w') pg.drawRectangle({x:X(o.x), y:Y(o.y + o.h), width:o.w * kx, height:o.h * ky, color:hexRgb(o.fc), borderWidth:0});
    else if(o.k === 'r') pg.drawRectangle({x:X(o.x), y:Y(o.y + o.h), width:o.w * kx, height:o.h * ky, color:fill(o.fc), borderColor:fill(o.sc), borderWidth:o.sc ? o.lw : 0});
    else if(o.k === 'e') pg.drawEllipse({x:X(o.x + o.w / 2), y:Y(o.y + o.h / 2), xScale:o.w * kx / 2, yScale:o.h * ky / 2, color:fill(o.fc), borderColor:fill(o.sc), borderWidth:o.sc ? o.lw : 0});
    else if(o.k === 'l' || o.k === 'a'){
      const ln = (a, b, c, e) => pg.drawLine({start:{x:X(a), y:Y(b)}, end:{x:X(c), y:Y(e)}, thickness:o.lw, color:hexRgb(o.sc), lineCap:PDFLib.LineCapStyle.Round});
      ln(o.x1, o.y1, o.x2, o.y2); if(o.k === 'a') ahead(o).forEach(q => ln(o.x2, o.y2, q[0], q[1]));
    }else if(o.k === 'i'){
      let im = cache.im && cache.im.get(o.f);
      if(!im){
        const by = new Uint8Array(await readFile(o.f)), jpg = by[0] === 0xFF && by[1] === 0xD8, png = by[0] === 0x89 && by[1] === 0x50;
        if(jpg && !exifRot(by)) im = await doc.embedJpg(by); else if(png){ try{ im = await doc.embedPng(by); }catch(e){} }
        if(!im) im = await doc.embedPng(await toPng(o.f)); (cache.im = cache.im || new Map()).set(o.f, im);
      }
      pg.drawImage(im, {x:X(o.x), y:Y(o.y + o.h), width:o.w * kx, height:o.h * ky});
    }else if(o.k === 'hl'){
      o.rects.forEach(r => pg.drawRectangle({x:X(r[0]), y:Y(r[1] + r[3]), width:r[2] * kx, height:r[3] * ky, color:hexRgb(o.c), opacity:.4, borderWidth:0}));
    }else if(o.k === 'ul' || o.k === 'st'){
      o.rects.forEach(r => { const y = r[1] + (o.k === 'ul' ? r[3] * 1.08 : r[3] * .45); pg.drawLine({start:{x:X(r[0]), y:Y(y)}, end:{x:X(r[0] + r[2]), y:Y(y)}, thickness:Math.max(1, r[3] * .07), color:hexRgb(o.c)}); });
    }else if(o.k === 's'){
      for(let i = 1; i < o.pts.length; i++) pg.drawLine({start:{x:X(o.pts[i - 1][0]), y:Y(o.pts[i - 1][1])}, end:{x:X(o.pts[i][0]), y:Y(o.pts[i][1])}, thickness:o.lw, color:hexRgb(o.c), lineCap:PDFLib.LineCapStyle.Round});
    }else if(o.k === 'n'){                              // a visible note icon, plus a real PDF note so other apps show the text
      const x = X(o.x), y = Y(o.y + 24), w = 24 * kx, h = 24 * ky;
      pg.drawRectangle({x, y, width:w, height:h, color:hexRgb(o.c), borderColor:hexRgb('#b8860b'), borderWidth:1});
      [8, 13, 18].forEach((dy, i) => pg.drawLine({start:{x:x + 5 * kx, y:Y(o.y + dy)}, end:{x:x + (i === 2 ? 14 : 19) * kx, y:Y(o.y + dy)}, thickness:1.5, color:hexRgb('#8a6d00')}));
      try{
        const a = f(x, y), b2 = f(x + w, y + h);
        pg.node.addAnnot(doc.context.register(doc.context.obj({Type:'Annot', Subtype:'Text', Rect:[Math.min(a[0], b2[0]), Math.min(a[1], b2[1]), Math.max(a[0], b2[0]), Math.max(a[1], b2[1])], Contents:PDFLib.PDFHexString.fromText(o.text), Name:'Comment', C:[1, .89, .48], F:4})));
      }catch(e){}
    }else if(o.k === 't') await drawTextObj(doc, pg, o, X, Y, kx, ky, cache);
  }
  pg.pushOperators(PDFLib.popGraphicsState());
  if(cr){
    const f = (x, y) => [M[0] * x + M[2] * y + M[4], M[1] * x + M[3] * y + M[5]], a = f(X(cr.x), Y(cr.y)), b = f(X(cr.x + cr.w), Y(cr.y + cr.h));
    pg.setCropBox(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.abs(b[0] - a[0]), Math.abs(b[1] - a[1]));
  }
}

/* ---------- pages: copy, move, select, extract, split ---------- */
let skipAuto = false, moveSet = null, SP = null;
const cloneD = d => ({...d, _s:false, ov:d.ov && d.ov.map(o => ({...o, rects:o.rects && o.rects.map(r => r.slice()), pts:o.pts && o.pts.map(q => q.slice())})), crop:d.crop && {...d.crop}, ed:d.ed && {...d.ed}});
async function addFiles(parts){                         // parts: [[bytes, name], ...]  new PDFs join your list
  const fs = parts.map(([b, n]) => new File([b], n.replace(/[\\/:*?"<>|]/g, '_') + '.pdf', {type:'application/pdf', lastModified:Date.now()}));
  if(['img', 'zip'].includes(TASKS[$('#task').value].acc)) setTask('all');
  skipAuto = true; try{ await add(fs); }finally{ skipAuto = false; }
  toast(fs.length === 1 ? `Created ${fs[0].name}. It is in your list now.` : `Added ${fs.length} PDFs to your list.`);
}
async function pdfFromPages(pages, docs){
  const out = await PDFDocument.create(); cancelFlag = false;
  await addEdited(out, {pg:pages}, $('#size').value, null, () => {}, docs);
  if(!out.getPageCount()) throw new Error('No pages were chosen.');
  return out.save();
}
function movePrompt(set){
  moveSet = set; const n = ed.list.length;
  $('#qt').textContent = `Move ${set.length === 1 ? 'this page' : set.length + ' pages'} to position (1 to ${n})`; $('#qn').max = n; $('#qn').value = ed.list.indexOf(set[0]) + 1;
  $('#qd').hidden = false; setTimeout(() => $('#qn').select(), 60);
}
$('#qok').onclick = () => {
  const L = ed.list, set = moveSet; $('#qd').hidden = true; if(!set) return;
  const pos = Math.min(L.length - set.length + 1, Math.max(1, Math.round(+$('#qn').value) || 1));
  const block = L.filter(d => set.includes(d)), rest = L.filter(d => !set.includes(d));
  rest.splice(pos - 1, 0, ...block); L.splice(0, L.length, ...rest); ed.dirty = true; edRender();   // first moved page lands at that position
};
$('#qno').onclick = () => { $('#qd').hidden = true; };
$('#esel').onclick = () => { ed.sm = !ed.sm; if(!ed.sm) ed.list.forEach(d => { d._s = false; }); edRender(); };
$('#esplit').onclick = () => openSplit(ed.list, stem(ed.it.file));
$('#esb').addEventListener('click', async e => {
  const b = e.target.closest('[data-e]'); if(!b || !ed) return; const L = ed.list, S = L.filter(d => d._s), a = b.dataset.e;
  if(a === 'all' || a === 'none'){ L.forEach(d => { d._s = a === 'all'; }); return edRender(); }
  if(!S.length) return toast('Tap the pages you want first.');
  if(a === 'mv') return movePrompt(S);
  if(a === 'ex'){
    try{ toast('Making the new PDF…'); await tick(); await addFiles([[await pdfFromPages(S, new Map()), stem(ed.it.file) + ' - extract']]); }catch(x){ toast('Could not extract: ' + (x.message || x)); }
    return;
  }
  if(a === 'rot') S.forEach(d => { d.rot = (d.rot + 90) % 360; d.u = null; });
  else if(a === 'del'){ for(let i = L.length - 1; i >= 0; i--) if(L[i]._s) L.splice(i, 1); }
  else if(a === 'dup'){ for(let i = L.length - 1; i >= 0; i--) if(L[i]._s) L.splice(i + 1, 0, cloneD(L[i])); }
  ed.dirty = true; edRender();
});
function parseRanges(str, n){
  const out = [];
  for(const tok of str.split(/[,;\s]+/).filter(Boolean)){
    const m = tok.match(/^(\d*)-(\d*)$/) || tok.match(/^(\d+)$/);
    if(!m) throw new Error(`"${tok}" is not a page range. Use numbers like 3, 2-5 or 7-.`);
    const a = m.length === 2 ? +m[1] : (m[1] ? +m[1] : 1), b = m.length === 2 ? +m[1] : (m[2] ? +m[2] : n);
    if(!(a >= 1 && b >= a && b <= n)) throw new Error(`"${tok}" does not fit this PDF. It has ${n} pages.`);
    out.push([a, b]);
  }
  if(!out.length) throw new Error('Type the page numbers first.');
  return out;
}
function splitPlan(L, nm, mode, every, text){
  const n = L.length, rng = (a, b) => a === b ? `${nm} - page ${a}` : `${nm} - pages ${a}-${b}`;
  if(mode === 'each') return L.map((d, i) => ({name:rng(i + 1, i + 1), pages:[d]}));
  if(mode === 'every'){ const k = Math.max(1, Math.round(every) || 1), out = []; for(let a = 1; a <= n; a += k) out.push({name:rng(a, Math.min(n, a + k - 1)), pages:L.slice(a - 1, a - 1 + k)}); return out; }
  const r = parseRanges(text, n);
  if(mode === 'ranges') return r.map(([a, b]) => ({name:rng(a, b), pages:L.slice(a - 1, b)}));
  return [{name:`${nm} - extract`, pages:r.flatMap(([a, b]) => L.slice(a - 1, b))}];   // extract: one PDF with all those pages
}
function spMode(){
  const m = $('#spm').value; $('#spn').hidden = m !== 'every'; $('#spr').hidden = !(m === 'ranges' || m === 'extract');
  $('#sprv').placeholder = m === 'ranges' ? 'For example: 1-3, 4-6, 7-' : 'For example: 1-3, 7, 9-12'; $('#spz').textContent = 'Download';
}
function openSplit(list, name){ SP = {list, name}; $('#sps').textContent = `This PDF has ${list.length} page${list.length === 1 ? '' : 's'}.`; $('#spst').textContent = ''; spMode(); $('#spd').hidden = false; }
async function openItemSplit(it){
  let list; try{ list = it.pg || await fresh(it); }catch(e){ return toast('Could not open this PDF.'); }
  openSplit(list, stem(it.file));
}
async function runSplit(toList){
  let plan; try{ plan = splitPlan(SP.list, SP.name, $('#spm').value, +$('#spnv').value, $('#sprv').value); }catch(e){ return toast(e.message); }
  const btns = ['#spz', '#spl', '#spx'].map($); btns.forEach(b => { b.disabled = true; }); const docs = new Map(), done = [];
  try{
    for(let i = 0; i < plan.length; i++){ $('#spst').textContent = `Making ${i + 1} of ${plan.length}…`; await tick(); done.push([await pdfFromPages(plan[i].pages, docs), plan[i].name]); }
    if(toList){ $('#spd').hidden = true; await addFiles(done); }
    else if(done.length === 1) save({blob:new Blob([done[0][0]], {type:'application/pdf'}), name:done[0][1]});
    else{
      if(typeof JSZip === 'undefined') throw new Error('The ZIP tool could not load. Please reinstall the app.');
      const Z = new JSZip(), used = new Set();
      done.forEach(([b, n]) => { let nm = n, c = 1; while(used.has(nm)) nm = `${n} (${++c})`; used.add(nm); Z.file(nm.replace(/[\\/:*?"<>|]/g, '_') + '.pdf', b); });
      save({blob:await Z.generateAsync({type:'blob', compression:'STORE'}), name:SP.name + ' - split', zip:true});
    }
    $('#spst').textContent = `Done. ${done.length} PDF${done.length > 1 ? 's' : ''} made.`;
  }catch(e){ toast('Could not split: ' + (e.message || e)); $('#spst').textContent = ''; }
  btns.forEach(b => { b.disabled = false; });
}
$('#spm').onchange = spMode; $('#spz').onclick = () => runSplit(false); $('#spl').onclick = () => runSplit(true); $('#spx').onclick = () => { $('#spd').hidden = true; };

/* ---------- create new PDFs ---------- */
const PAGE = {a4:[595.28, 841.89], letter:[612, 792], a5:[419.53, 595.28]};
const stamp = () => { const d = new Date(), p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}-${p(d.getMinutes())}`; };
let scan = [];
function openMk(){ $('#mk').hidden = false; document.body.style.overflow = 'hidden'; }
function closeMk(){ $('#mk').hidden = true; document.body.style.overflow = ''; }
async function mk(fn){ try{ await fn(); }catch(e){ toast('Could not create the PDF: ' + (e.message || e)); } }
function addMade(bytes, name){                          // the new PDF joins your list like any other file
  const f = new File([bytes], name.replace(/[\\/:*?"<>|]/g, '_') + '.pdf', {type:'application/pdf', lastModified:Date.now()});
  if(['img', 'zip'].includes(TASKS[$('#task').value].acc)) setTask('all');
  closeMk(); add([f]); toast(`Created ${f.name}. It is in your list now.`);
}
async function blocksToPdf(blocks, o){                  // blocks: [{text, size, bold, indent, gap}]
  const [PW, PH] = o.page, mg = 54, S = 2.5, FONT = 'Helvetica, Arial, sans-serif', doc = await PDFDocument.create();
  doc.setTitle(o.title || 'Document'); doc.setCreator('PDF Maker');
  const F = await doc.embedFont(PDFLib.StandardFonts.Helvetica), FB = await doc.embedFont(PDFLib.StandardFonts.HelveticaBold);
  let flat = false, page, c, g, y = 0;
  try{ blocks.forEach(b => (b.bold ? FB : F).widthOfTextAtSize(b.text.replace(/\s/g, ' '), 10)); }catch(e){ flat = true; }   // other alphabets: draw the text as pictures
  const width = (t, sz, bold) => { if(flat){ g.font = `${bold ? 'bold ' : ''}${sz*S}px ${FONT}`; return g.measureText(t).width / S; } return (bold ? FB : F).widthOfTextAtSize(t, sz); };
  const flush = async () => { if(flat && c){ const png = await new Promise(r => c.toBlob(r, 'image/png')); doc.addPage([PW, PH]).drawImage(await doc.embedPng(new Uint8Array(await png.arrayBuffer())), {x:0, y:0, width:PW, height:PH}); } };
  const newPage = async () => {
    await flush(); y = PH - mg;
    if(flat){ c = document.createElement('canvas'); c.width = Math.round(PW*S); c.height = Math.round(PH*S); g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.fillStyle = '#000'; }
    else page = doc.addPage([PW, PH]);
  };
  const put = async (t, x, sz, bold, lh) => {
    if(y - lh < mg) await newPage();
    y -= lh; if(!t) return;
    if(flat){ g.font = `${bold ? 'bold ' : ''}${sz*S}px ${FONT}`; g.fillText(t, x*S, (PH - y - lh*.25) * S); }
    else page.drawText(t, {x, y:y + lh*.25, size:sz, font:bold ? FB : F});
  };
  await newPage();
  for(const b of blocks){
    const sz = b.size, lh = sz * 1.35, x0 = mg + (b.indent || 0), maxW = PW - mg - x0; y -= b.gap || 0;
    for(const raw of b.text.replace(/\r/g, '').split('\n')){
      let line = '';
      for(let w of raw.replace(/\t/g, '    ').split(' ')){
        while(w.length > 1 && width(w, sz, b.bold) > maxW){      // one word wider than the page: split it
          let k = w.length; while(k > 1 && width(w.slice(0, k), sz, b.bold) > maxW) k--;
          if(line){ await put(line, x0, sz, b.bold, lh); line = ''; }
          await put(w.slice(0, k), x0, sz, b.bold, lh); w = w.slice(k);
        }
        const t = line ? line + ' ' + w : w;
        if(line && width(t, sz, b.bold) > maxW){ await put(line, x0, sz, b.bold, lh); line = w; } else line = t;
      }
      await put(line, x0, sz, b.bold, lh);
    }
  }
  await flush(); return await doc.save();
}
function htmlBlocks(html){                              // headings, paragraphs, lists, tables and code become simple text blocks
  const doc = new DOMParser().parseFromString(html, 'text/html'), out = [], H = {H1:24, H2:20, H3:17, H4:15, H5:13, H6:12};
  doc.querySelectorAll('script,style,noscript,svg,iframe,template').forEach(e => e.remove());
  doc.querySelectorAll('br').forEach(b => b.replaceWith('\u0001'));
  const norm = t => t.replace(/\s+/g, ' ').replace(/ ?\u0001 ?/g, '\n').trim(), sel = 'h1,h2,h3,h4,h5,h6,p,li,pre,blockquote,tr,dt,dd,figcaption,div';
  const title = (doc.title || '').trim(); if(title) out.push({text:title, size:24, bold:true, gap:0});
  doc.body.querySelectorAll(sel).forEach(el => {
    if(el.querySelector(sel)) return;                   // keep only the innermost blocks, so nothing repeats
    const tg = el.tagName, t = tg === 'TR' ? [...el.cells].map(x => norm(x.textContent)).join('   |   ') : tg === 'PRE' ? el.textContent.replace(/\s+$/, '') : norm(el.textContent);
    if(t) out.push({text:(tg === 'LI' ? '• ' : '') + t, size:H[tg] || 11, bold:!!H[tg], indent:tg === 'LI' ? 14 : 0, gap:H[tg] ? 10 : tg === 'LI' ? 2 : 6});
  });
  if(out.length < (title ? 2 : 1)){ const t = norm(doc.body.textContent || ''); if(t) out.push({text:t, size:11}); }
  return out;
}
async function fromFile(f){
  const ext = (f.name.split('.').pop() || '').toLowerCase(); let blocks;
  if(ext === 'docx'){
    if(typeof mammoth === 'undefined') throw new Error('The Word reader could not load. Please reinstall the app.');
    blocks = htmlBlocks((await mammoth.convertToHtml({arrayBuffer:await f.arrayBuffer()})).value);
  }else if(/^(html?|xhtml)$/.test(ext)) blocks = htmlBlocks(await f.text());
  else if(/^(doc|odt|rtf|pdf|xls|xlsx|ppt|pptx)$/.test(ext)) throw new Error('.' + ext + ' files can not be read here. Save the file as .docx or .txt first.');
  else blocks = [{text:await f.text(), size:11}];
  if(!blocks.length) throw new Error('No readable text was found in that file.');
  addMade(await blocksToPdf(blocks, {page:PAGE.a4, title:stem(f)}), stem(f));
}
$('#mkx').onclick = closeMk;
$('#bmk').onclick = () => mk(async () => {
  const n = Math.min(200, Math.max(1, Math.round(+$('#bn').value) || 1)); let [w, h] = PAGE[$('#bs').value]; if($('#bo').value === 'l') [w, h] = [h, w];
  const d = await PDFDocument.create(); for(let i = 0; i < n; i++) d.addPage([w, h]);
  addMade(await d.save(), 'Blank ' + stamp());
});
$('#tmk').onclick = () => mk(async () => {
  const t = $('#tt').value; if(!t.trim()) return toast('Type or paste some text first.');
  addMade(await blocksToPdf([{text:t, size:+$('#ts').value}], {page:PAGE[$('#tp').value], title:'Text'}), 'Text ' + stamp());
});
$('#hmk').onclick = () => mk(async () => {
  const t = $('#ht').value.trim(); if(!t) return toast('Paste the page\'s HTML first, or choose a saved HTML file.');
  const b = htmlBlocks(t); if(!b.length) throw new Error('No readable text was found.');
  addMade(await blocksToPdf(b, {page:PAGE.a4, title:'Web page'}), 'Web page ' + stamp());
});
$('#hpick').onclick = () => { $('#fdoc').accept = '.html,.htm,text/html'; $('#fdoc').click(); };
$('#dpick').onclick = () => { $('#fdoc').accept = '.txt,.md,.csv,.log,.json,.xml,.docx,.html,.htm,text/plain'; $('#fdoc').click(); };
$('#fdoc').onchange = e => { const f = e.target.files[0]; e.target.value = ''; if(f) mk(() => fromFile(f)); };
function drawScan(){
  $('#sl').innerHTML = scan.map((f, i) => `<div class="sp"><img src="${f._u || (f._u = URL.createObjectURL(f))}" alt=""><i>${i+1}</i><button data-r="${i}" aria-label="Remove page ${i+1}">✕</button></div>`).join('');
  $('#smk').disabled = !scan.length; $('#smk').textContent = scan.length ? `Create PDF from ${scan.length} page${scan.length > 1 ? 's' : ''}` : 'Create PDF';
}
$('#scam').onclick = () => $('#fcam').click();
$('#sgal').onclick = () => $('#fgal').click();
$('#fcam').onchange = $('#fgal').onchange = async e => { const raw = [...e.target.files]; e.target.value = ''; scan.push(...await snap(raw)); drawScan(); };
$('#sl').onclick = e => { const b = e.target.closest('[data-r]'); if(!b) return; const [f] = scan.splice(+b.dataset.r, 1); URL.revokeObjectURL(f._u); drawScan(); };
$('#smk').onclick = () => mk(async () => {
  const d = await PDFDocument.create(), size = $('#ssz').value;
  for(const f of scan) await addImage(d, f, await f.arrayBuffer(), size, null);
  const bytes = await d.save(); scan.forEach(f => URL.revokeObjectURL(f._u)); scan = []; drawScan(); addMade(bytes, 'Scan ' + stamp());
});

/* ---------- PDF viewer ---------- */
let V = null, scrollQ = 0;
async function openViewer(title, bytes, o = {}){
  $('#vt').textContent = title; $('#modal').hidden = false; document.body.style.overflow = 'hidden';
  $('#dl').hidden = !o.save; $('#dl').onclick = o.save || null;
  const box = $('#pages'); closeV(); box.innerHTML = '';
  if(o.img){ $('#tb').hidden = $('#nav').hidden = $('#sb').hidden = true; box.innerHTML = `<img class="pg" style="width:100%;max-width:820px;height:auto" src="${o.img}" alt="">`; return; }
  $('#tb').hidden = $('#nav').hidden = false; box.innerHTML = '<p class="empty">Opening…</p>';
  try{ await loadV(title, bytes); }catch(e){ box.textContent = 'Could not open this PDF: ' + (e.message || e); }
}
function closeV(){ if(V){ if(V.io) V.io.disconnect(); try{ V.pdf.destroy(); }catch(e){} V = null; } }
async function loadV(title, bytes){
  const pdf = await pdfjsLib.getDocument({data:bytes.slice()}).promise;
  const v = V = {pdf, bytes, title, n:pdf.numPages, cur:1, zoom:1, fit:'w', rot:0, mode:'scroll', dims:[], els:[], txt:{}, ms:[], mi:-1, q:'', lock:0};
  const box = $('#pages'); box.innerHTML = ''; box.classList.remove('dark');
  $('#th2').hidden = true; $('#th2').innerHTML = ''; $('#sb').hidden = true; $('#sq').value = ''; $('#sc').textContent = '';
  $('#ptot').textContent = v.n; $('#pn').max = v.n; $('#pn').value = 1; $('#vmode').textContent = 'One page';
  document.querySelectorAll('#tb .on').forEach(b => b.classList.remove('on'));
  for(let n = 1; n <= v.n; n++){
    const p = await pdf.getPage(n); if(V !== v) return;
    const b = p.getViewport({scale:1}); v.dims.push({w:b.width, h:b.height});
  }
  for(let n = 1; n <= v.n; n++){ const d = document.createElement('div'); d.className = 'pg'; d._n = n; d._g = 0; v.els.push(d); box.append(d); }
  v.io = new IntersectionObserver(es => es.forEach(e => { const d = e.target; if(e.isIntersecting && !d._r){ d._r = 1; draw(d); } }), {root:box, rootMargin:'700px'});
  relayout(false); goto(1, false);
}
function relayout(keep = true){                       // sizes every page for the current zoom, fit and rotation
  const v = V; if(!v) return; const box = $('#pages'), W = Math.max(120, box.clientWidth - 24), H = Math.max(120, box.clientHeight - 24);
  v.sig = box.clientWidth + 'x' + (v.fit === 'p' ? box.clientHeight : 0);
  v.els.forEach((d, i) => {
    const sw = v.rot % 180, {w, h} = v.dims[i], pw = sw ? h : w, ph = sw ? w : h;
    const cw = (v.fit === 'p' ? Math.min(W, H * pw / ph) : W) * v.zoom;
    d.style.width = cw + 'px'; d.style.height = cw * ph / pw + 'px'; d._r = 0; d._g++; d._tc = null;
    d.hidden = v.mode === 'single' && i + 1 !== v.cur;
    d.innerHTML = '<canvas></canvas><div class="tl"></div><div class="hl"></div>';
    v.io.unobserve(d); v.io.observe(d);
  });
  if(keep) goto(v.cur, false);
}
async function getText(n){ const v = V; if(!v.txt[n]) v.txt[n] = await (await v.pdf.getPage(n)).getTextContent(); return v.txt[n]; }
async function draw(d){
  const v = V, gen = d._g, n = d._n; if(!v) return;
  const p = await v.pdf.getPage(n); if(V !== v || d._g !== gen) return;
  const rot = (p.rotate + v.rot) % 360, b = p.getViewport({scale:1, rotation:rot}), k = parseFloat(d.style.width) / b.width;
  let sc = k * Math.min(devicePixelRatio || 1, 2); const area = b.width * b.height * sc * sc; if(area > 16e6) sc *= Math.sqrt(16e6 / area);
  const c = d.firstChild, vp = p.getViewport({scale:sc, rotation:rot}); c.width = vp.width; c.height = vp.height;
  await p.render({canvasContext:c.getContext('2d'), viewport:vp}).promise; if(V !== v || d._g !== gen) return;
  const tc = await getText(n); if(V !== v || d._g !== gen) return;
  d._tc = tc; d._v = p.getViewport({scale:k, rotation:rot});
  const tl = d.querySelector('.tl'); tl.style.setProperty('--scale-factor', k);
  try{ pdfjsLib.renderTextLayer({textContentSource:tc, container:tl, viewport:d._v, textDivs:[]}); }catch(e){}
  paint(d);
}
function rects(tc, vp, m){                            // highlight boxes (in screen pixels) for one search match
  return m.parts.map(({i, a, b}) => {
    const it = tc.items[i], t = it.transform, len = it.str.length || 1, L = Math.hypot(t[0], t[1]) || 1, dx = t[0] / L, dy = t[1] / L, W = it.width;
    const P = (u, w) => pdfjsLib.Util.applyTransform([t[4] + dx*W*u - dy*w, t[5] + dy*W*u + dx*w], vp.transform);
    const q = [P(a/len, 0), P(b/len, 0), P(b/len, it.height), P(a/len, it.height)], xs = q.map(z => z[0]), ys = q.map(z => z[1]), x = Math.min(...xs), y = Math.min(...ys);
    return [x, y, Math.max(...xs) - x, Math.max(...ys) - y];
  });
}
function paint(d){
  const v = V, hl = d.querySelector('.hl'); if(!v || !hl || !d._tc || !d._v) return; hl.innerHTML = '';
  v.ms.forEach((m, i) => { if(m.n !== d._n) return;
    for(const r of rects(d._tc, d._v, m)){ const b = document.createElement('b'); if(i === v.mi) b.className = 'cur'; b.style.cssText = `left:${r[0]}px;top:${r[1]}px;width:${r[2]}px;height:${r[3]}px`; hl.append(b); }
  });
  if(v.scrollTo){ const cur = hl.querySelector('.cur'); if(cur){ v.scrollTo = 0; cur.scrollIntoView({block:'center', inline:'center'}); } }
}
const mark = () => { if(V) [...$('#th2').children].forEach((t, i) => t.classList.toggle('on', i + 1 === V.cur)); };
function goto(n, smooth = true){
  const v = V; if(!v) return; n = Math.min(v.n, Math.max(1, Math.round(n) || 1)); v.cur = n; v.lock = Date.now() + 700; $('#pn').value = n;
  const box = $('#pages');
  if(v.mode === 'single'){ v.els.forEach((d, i) => { d.hidden = i + 1 !== n; }); box.scrollTop = 0; }
  else box.scrollTo({top:v.els[n-1].offsetTop - 8, behavior:smooth ? 'smooth' : 'auto'});
  mark();
}
$('#pages').onscroll = () => {
  if(!V || V.mode !== 'scroll' || scrollQ || Date.now() < V.lock) return;
  scrollQ = requestAnimationFrame(() => {
    scrollQ = 0; if(!V) return; const box = $('#pages'), y = box.scrollTop + box.clientHeight * .35; let c = 1;
    for(const d of V.els){ if(d.offsetTop <= y) c = d._n; else break; }
    if(c !== V.cur){ V.cur = c; $('#pn').value = c; mark(); }
  });
};
function toggleThumbs(){
  const t = $('#th2'); t.hidden = !t.hidden; if(t.hidden || t.children.length) return mark();
  const v = V; t.innerHTML = v.dims.map((d, i) => `<button class="tn" data-p="${i+1}"><canvas width="100" height="${Math.round(100 * d.h / d.w)}"></canvas>${i+1}</button>`).join('');
  const io = new IntersectionObserver(es => es.forEach(async e => {
    if(!e.isIntersecting) return; io.unobserve(e.target);
    const p = await v.pdf.getPage(+e.target.dataset.p), b = p.getViewport({scale:1}), vp = p.getViewport({scale:100 / b.width * Math.min(devicePixelRatio || 1, 2)}), c = e.target.firstChild;
    c.width = vp.width; c.height = vp.height; await p.render({canvasContext:c.getContext('2d'), viewport:vp}).promise;
  }), {root:t, rootMargin:'300px'});
  t.querySelectorAll('.tn').forEach(b => io.observe(b)); mark();
}
$('#th2').onclick = e => { const b = e.target.closest('.tn'); if(!b) return; goto(+b.dataset.p); if(innerWidth < 700){ $('#th2').hidden = true; document.querySelector('[data-v="thumbs"]').classList.remove('on'); } };

async function doSearch(){
  const v = V; if(!v) return; const q = $('#sq').value.trim().toLowerCase(); v.q = q; v.ms = []; v.mi = -1; v.els.forEach(d => paint(d));
  $('#sc').textContent = ''; if(!q) return;
  for(let n = 1; n <= v.n; n++){
    if(V !== v || v.q !== q) return;
    const tc = await getText(n), items = tc.items, map = []; let str = '';
    items.forEach((it, i) => { if(it.str === undefined) return; map.push([str.length, i]); str += it.str + (it.hasEOL ? ' ' : ''); });
    const low = str.toLowerCase(); let at = 0;
    while((at = low.indexOf(q, at)) !== -1){
      const end = at + q.length, parts = [];
      map.forEach(([st, i]) => { const a = Math.max(at, st), b = Math.min(end, st + items[i].str.length); if(b > a) parts.push({i, a:a - st, b:b - st}); });
      if(parts.length) v.ms.push({n, parts}); at = end;
    }
    $('#sc').textContent = `Searching ${n}/${v.n}, ${v.ms.length} found`;
    if(v.ms.length && v.mi < 0){ v.mi = 0; showMatch(); }
    if(n % 6 === 0) await tick();
  }
  $('#sc').textContent = v.ms.length ? `${v.mi + 1} of ${v.ms.length}` : 'No matches';
}
function showMatch(){ const v = V, m = v.ms[v.mi]; v.scrollTo = 1; goto(m.n, false); v.els.forEach(d => paint(d)); }
function stepMatch(dir){
  const v = V; if(!v || !v.ms.length) return; v.mi = (v.mi + dir + v.ms.length) % v.ms.length;
  $('#sc').textContent = `${v.mi + 1} of ${v.ms.length}`; showMatch();
}
let searchT; $('#sq').oninput = () => { clearTimeout(searchT); searchT = setTimeout(doSearch, 450); };
$('#sq').onkeydown = e => { if(e.key !== 'Enter') return; e.preventDefault(); clearTimeout(searchT); if(V && V.ms.length && V.q === $('#sq').value.trim().toLowerCase()) stepMatch(e.shiftKey ? -1 : 1); else doSearch(); };
$('#pn').onchange = () => goto(+$('#pn').value);

function fullScreen(){
  const el = $('#modal'), on = document.fullscreenElement || document.webkitFullscreenElement;
  if(on) (document.exitFullscreen || document.webkitExitFullscreen).call(document);
  else if(el.requestFullscreen || el.webkitRequestFullscreen) (el.requestFullscreen || el.webkitRequestFullscreen).call(el);
  else toast('Full screen is not available in this browser.');
}
async function copyPage(){
  const tc = await getText(V.cur), t = tc.items.map(i => (i.str || '') + (i.hasEOL ? '\n' : '')).join('').trim(); let ok = false;
  if(!t) return toast('No selectable text on this page. It may be a scanned picture.');
  try{ await navigator.clipboard.writeText(t); ok = true; }catch(e){
    const a = document.createElement('textarea'); a.value = t; document.body.append(a); a.select(); try{ ok = document.execCommand('copy'); }catch(x){} a.remove();
  }
  toast(ok ? `Copied the text of page ${V.cur}. You can also touch and hold text to select it.` : 'Could not copy. Touch and hold the text to select it instead.');
}
async function shareIt(){
  if(NA){ try{ await nativeSend(new Blob([V.bytes], {type:'application/pdf'}), ((V.title || 'document').replace(/\.pdf$/i, '').replace(/[\\/:*?"<>|]/g, '_') || 'document') + '.pdf', 'share'); }catch(e){ toast('Sharing did not work.'); } return; }
  const f = new File([V.bytes], ((V.title || 'document').replace(/\.pdf$/i, '').replace(/[\\/:*?"<>|]/g, '_') || 'document') + '.pdf', {type:'application/pdf'});
  if(navigator.canShare && navigator.canShare({files:[f]})){ try{ await navigator.share({files:[f], title:f.name}); }catch(e){ if(e.name !== 'AbortError') toast('Sharing did not work.'); } }
  else{ const a = document.createElement('a'); a.href = URL.createObjectURL(f); a.download = f.name; document.body.append(a); a.click(); a.remove(); toast('Sharing is not available here, so the PDF was saved instead.'); }
}
async function printIt(){
  if(NA){ try{ await nativeSend(new Blob([V.bytes], {type:'application/pdf'}), ((V.title || 'document').replace(/\.pdf$/i, '').replace(/[\\/:*?"<>|]/g, '_') || 'document') + '.pdf', 'print'); }catch(e){ toast('Printing did not work.'); } return; }
                              // pages are drawn as pictures, so printing works on phones too
  const v = V, box = document.createElement('div'); box.id = 'pj'; toast('Getting the pages ready to print…');
  for(let n = 1; n <= v.n; n++){
    const p = await v.pdf.getPage(n), b = p.getViewport({scale:1}), vp = p.getViewport({scale:Math.min(2, 2600 / Math.max(b.width, b.height))}), c = document.createElement('canvas');
    c.width = vp.width; c.height = vp.height; await p.render({canvasContext:c.getContext('2d'), viewport:vp}).promise;
    const img = new Image(); img.src = URL.createObjectURL(await new Promise(r => c.toBlob(r, 'image/jpeg', .92))); await img.decode().catch(() => {}); box.append(img); await tick();
  }
  document.body.append(box);
  const done = () => { box.remove(); window.removeEventListener('afterprint', done); }; window.addEventListener('afterprint', done); setTimeout(done, 300000);
  window.print();
}
$('#fv').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if(f) openViewer(f.name, new Uint8Array(await f.arrayBuffer())); };
$('#modal').addEventListener('click', e => {
  const b = e.target.closest('[data-v]'); if(!b || !V) return; const a = b.dataset.v, v = V, setFit = f => { v.fit = f; v.zoom = 1; relayout(); };
  if(a === 'thumbs'){ toggleThumbs(); b.classList.toggle('on', !$('#th2').hidden); }
  else if(a === 'search'){ const s = $('#sb'); s.hidden = !s.hidden; b.classList.toggle('on', !s.hidden); if(!s.hidden) $('#sq').focus(); }
  else if(a === 'in'){ v.zoom = Math.min(5, v.zoom * 1.25); relayout(); }
  else if(a === 'out'){ v.zoom = Math.max(.4, v.zoom / 1.25); relayout(); }
  else if(a === 'fw') setFit('w');
  else if(a === 'fp') setFit('p');
  else if(a === 'mode'){ v.mode = v.mode === 'scroll' ? 'single' : 'scroll'; b.textContent = v.mode === 'scroll' ? 'One page' : 'Scroll'; relayout(); }
  else if(a === 'rot'){ v.rot = (v.rot + 90) % 360; relayout(); }
  else if(a === 'dark'){ $('#pages').classList.toggle('dark'); b.classList.toggle('on'); }
  else if(a === 'full') fullScreen();
  else if(a === 'copy') copyPage();
  else if(a === 'share') shareIt();
  else if(a === 'print') printIt();
  else if(a === 'open') $('#fv').click();
  else if(a === 'prev') goto(v.cur - 1);
  else if(a === 'next') goto(v.cur + 1);
  else if(a === 'sp') stepMatch(-1);
  else if(a === 'sn') stepMatch(1);
  else if(a === 'sx'){ $('#sb').hidden = true; $('#sq').value = ''; doSearch(); document.querySelector('[data-v="search"]').classList.remove('on'); }
});
let resizeT; const onResize = () => { clearTimeout(resizeT); resizeT = setTimeout(() => { const v = V, box = $('#pages'); if(v && !$('#modal').hidden && v.sig !== box.clientWidth + 'x' + (v.fit === 'p' ? box.clientHeight : 0)) relayout(); }, 250); };
addEventListener('resize', onResize); document.addEventListener('fullscreenchange', onResize);
$('#close').onclick = () => {
  if(document.fullscreenElement) document.exitFullscreen(); closeV(); $('#modal').hidden = true;
  $('#pages').innerHTML = ''; $('#th2').innerHTML = ''; document.body.style.overflow = '';
};
function segQ(){ document.querySelectorAll('#qseg [data-q]').forEach(b => b.classList.toggle('on', b.dataset.q === $('#qual').value)); }
$('#qseg').onclick = e => { const b = e.target.closest('[data-q]'); if(!b) return; $('#qual').value = b.dataset.q; $('#qual').onchange(); };
$('#oseg').onclick = e => { const b = e.target.closest('[data-o]'); if(!b) return; $('#outm').value = b.dataset.o; $('#outm').onchange(); };
/* ---------- ZIP editor ---------- */
const MIME = {jpg:'image/jpeg', jpeg:'image/jpeg', png:'image/png', gif:'image/gif', webp:'image/webp', bmp:'image/bmp', avif:'image/avif', pdf:'application/pdf', txt:'text/plain', md:'text/plain', csv:'text/csv', json:'application/json', xml:'text/xml', html:'text/html', htm:'text/html', log:'text/plain'};
const extOf = n => (String(n).match(/\.([A-Za-z0-9]+)$/) || [, ''])[1].toLowerCase();
const kindOf = n => /^(jpe?g|png|gif|webp|bmp|avif)$/.test(extOf(n)) ? 'img' : extOf(n) === 'pdf' ? 'pdf' : /^(txt|md|csv|log|json|xml|html?)$/.test(extOf(n)) ? 'text' : 'other';
const isZip = f => /\.zip$/i.test(f.name) || /zip/i.test(f.type || '');
const baseName = p => p.slice(p.lastIndexOf('/') + 1), dirName = p => p.includes('/') ? p.slice(0, p.lastIndexOf('/') + 1) : '';
function cleanPath(p){                                // safe relative path: no "..", no leading slash, no odd characters
  return String(p).replace(/\\/g, '/').split('/').filter(x => x.trim() && x !== '.' && x !== '..').map(x => x.replace(/[\u0000-\u001f<>:"|?*]/g, '_')).join('/').slice(0, 240);
}
const SORTS = {
  name:['Name', (a, b) => a.path.localeCompare(b.path, undefined, {numeric:true})],
  date:['Date', (a, b) => b.date - a.date],
  size:['Size', (a, b) => b.size - a.size],
  type:['Type', (a, b) => extOf(a.path).localeCompare(extOf(b.path)) || a.path.localeCompare(b.path, undefined, {numeric:true})]
};
let ZE = null, zeId = 0, zq = 'med';
const zeSorted = list => [...list].sort(SORTS[ZE.sort][1]);
function zeUnique(path, skipId){
  const taken = new Set(ZE.entries.filter(e => e.id !== skipId).map(e => e.path.toLowerCase()));
  const d = dirName(path), b = baseName(path), dot = b.lastIndexOf('.'), stem = dot > 0 ? b.slice(0, dot) : b, ext = dot > 0 ? b.slice(dot) : '';
  let p = path, n = 1; while(taken.has(p.toLowerCase())) p = `${d}${stem} (${++n})${ext}`; return p;
}
function zeMake(path, blob, date){
  const p = cleanPath(path) || 'file', typ = MIME[extOf(p)] || blob.type || 'application/octet-stream', b = blob.type === typ ? blob : new Blob([blob], {type:typ});
  return {id:++zeId, path:zeUnique(p), blob:b, size:b.size, date:date || new Date(), kind:kindOf(p), _s:false};
}
async function zipEntries(f, onp){
  const zip = await JSZip.loadAsync(await readFile(f)), names = Object.keys(zip.files).filter(n => !zip.files[n].dir), out = []; let total = 0;
  if(names.length > 5000) throw new Error('This ZIP has more than 5000 files.');
  for(const n of names){ const d = zip.files[n]._data; total += (d && d.uncompressedSize) || 0; }
  if(total > 1.5e9) throw new Error('This ZIP is too big to open on a phone (over 1.5 GB when unpacked).');
  for(let i = 0; i < names.length; i++){
    const e = zip.files[names[i]]; out.push({path:names[i], blob:await e.async('blob'), date:e.date});
    if(onp && i % 10 === 0){ onp(i + 1, names.length); await tick(); }
  }
  return out;
}
async function openZipEditor(files){
  if(typeof JSZip === 'undefined') return toast('The ZIP tool could not load. Please reinstall the app.');
  ZE = {name:stem(files[0]) + (files.length > 1 ? ' merged' : ''), entries:[], sort:'name', sm:false, filter:'', dirty:false, orig:null};
  try{
    for(const f of files){ const list = await zipEntries(f, (i, n) => toast(`Opening ${f.name}: ${i} of ${n}`)); list.forEach(x => ZE.entries.push(zeMake(x.path, x.blob, x.date))); }
  }catch(e){ ZE = null; return toast('Could not open the ZIP: ' + (/ncrypt/i.test(e.message || '') ? 'it has a password, which this app cannot open.' : (e.message || e))); }
  if(!ZE.entries.length){ ZE = null; return toast('That ZIP has no files inside.'); }
  ZE.orig = ZE.entries.map(e => ({...e})); $('#zet').textContent = ZE.name + '.zip'; $('#zef').value = ''; $('#zesort').textContent = 'Sort: ' + SORTS.name[0];
  $('#ze').hidden = false; zeRender(); toast(`${ZE.entries.length} file${ZE.entries.length === 1 ? '' : 's'} found.`);
}
function zeRender(){
  const Z = ZE; if(!Z) return; Z.warned = false; const q = Z.filter.trim().toLowerCase();
  const L = zeSorted(Z.entries.filter(e => !q || e.path.toLowerCase().includes(q)));
  $('#zel').innerHTML = L.map(e => {
    const th = e.kind === 'img' ? `<img src="${e.u || (e.u = URL.createObjectURL(e.blob))}" alt="" loading="lazy" decoding="async">` : esc((extOf(e.path) || 'FILE').slice(0, 4).toUpperCase());
    return `<div class="zi${e._s ? ' sel' : ''}" data-id="${e.id}"><div class="zt">${th}</div><div class="zm"><div class="nm">${esc(baseName(e.path))}</div><div class="sub">${esc(dirName(e.path))}${fmtSize(e.size)}, ${e.date.toLocaleDateString([], {dateStyle:'medium'})}</div></div><span class="zdots" aria-hidden="true" style="display:grid;place-items:center">⋯</span></div>`;
  }).join('') || '<p class="empty">No files match.</p>';
  $('#zecnt').textContent = `${L.length} of ${Z.entries.length}, ${fmtSize(Z.entries.reduce((a, e) => a + e.size, 0))}`;
  $('#zesb').hidden = !Z.sm; $('#zesel').classList.toggle('on', Z.sm); $('#zesel').textContent = Z.sm ? 'Done selecting' : 'Select'; zeCount();
}
const zeCount = () => { if(ZE) $('#zesn').textContent = `${ZE.entries.filter(e => e._s).length} selected`; };
function zeDelete(list){ for(const e of list){ if(e.u) URL.revokeObjectURL(e.u); ZE.entries.splice(ZE.entries.indexOf(e), 1); } }
function zprompt(title, value){ return new Promise(res => { $('#zit').textContent = title; $('#zin').value = value; $('#zid').hidden = false; zprompt.res = res; setTimeout(() => $('#zin').select(), 60); }); }
$('#zio').onclick = () => { $('#zid').hidden = true; const f = zprompt.res; zprompt.res = null; if(f) f($('#zin').value); };
$('#zix').onclick = () => { $('#zid').hidden = true; const f = zprompt.res; zprompt.res = null; if(f) f(null); };
function saveAs(blob, fname){                         // one file out of the ZIP, or a finished ZIP
  if(window.PDFMagicNative && typeof nativeSend === 'function'){ nativeSend(blob, fname, 'save').then(m => toast(m || 'Saved.')).catch(() => toast('Could not save the file.')); return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = fname; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
async function zeBuildZip(list, onp){
  if(typeof JSZip === 'undefined') throw new Error('The ZIP tool could not load. Please reinstall the app.');
  const zip = new JSZip();
  for(const e of list) zip.file(e.path, e.blob, {date:new Date(e.date.getTime() > 315532800000 ? e.date.getTime() : Date.now()), compression:e.kind === 'img' ? 'STORE' : 'DEFLATE'});
  return zip.generateAsync({type:'blob', streamFiles:true}, m => { if(onp) onp(Math.round(m.percent)); });
}
async function zeSaveZip(list, name){
  try{ toast('Making the ZIP…'); await tick(); saveAs(await zeBuildZip(list, p => toast(`Making the ZIP… ${p}%`)), name.replace(/[\\/:*?"<>|]/g, '_') + '.zip'); }
  catch(e){ toast('Could not make the ZIP: ' + (e.message || e)); }
}
async function zePreview(en){
  if(en.kind === 'img'){ en.u = en.u || URL.createObjectURL(en.blob); return openViewer(baseName(en.path), null, {img:en.u}); }
  if(en.kind === 'pdf') return openViewer(baseName(en.path), new Uint8Array(await en.blob.arrayBuffer()));
  if(en.kind === 'text'){ $('#tpt').textContent = (await en.blob.slice(0, 6000).text()) + (en.size > 6000 ? '\n…' : ''); $('#tpn').textContent = en.path; $('#tpd').hidden = false; return; }
  toast('There is no preview for this kind of file. You can still rename, move, replace or delete it.');
}
async function zeRotate(list, deg){                   // pictures are re-saved at high quality after turning
  let bad = 0;
  for(const en of list){
    if(en.kind !== 'img') continue;
    try{
      const bmp = await createImageBitmap(en.blob), q = deg % 180, c = document.createElement('canvas'); c.width = q ? bmp.height : bmp.width; c.height = q ? bmp.width : bmp.height;
      const g = c.getContext('2d'); g.translate(c.width / 2, c.height / 2); g.rotate(deg * Math.PI / 180); g.drawImage(bmp, -bmp.width / 2, -bmp.height / 2); if(bmp.close) bmp.close();
      const keep = /^(png|gif|webp|bmp|avif)$/.test(extOf(en.path)), blob = await new Promise(r => c.toBlob(r, keep ? 'image/png' : 'image/jpeg', .95));
      if(!blob) throw new Error('no picture');
      if(en.u){ URL.revokeObjectURL(en.u); en.u = null; }
      en.blob = blob; en.size = blob.size; if(keep && extOf(en.path) !== 'png') en.path = zeUnique(en.path.replace(/\.[^./]+$/, '.png'), en.id);
    }catch(e){ bad++; }
  }
  if(bad) toast(`${bad} picture${bad > 1 ? 's' : ''} could not be turned.`);
}
async function zeToPdf(list){
  const imgs = zeSorted(list.filter(x => x.kind === 'img')); if(!imgs.length) return toast('Pick some pictures first.');
  try{ toast('Making the PDF…'); await tick(); const out = await PDFDocument.create(); for(const x of imgs) await addImage(out, x.blob, await x.blob.arrayBuffer(), $('#size').value, null); await addFiles([[await out.save(), ZE.name]]); }
  catch(e){ toast('Could not make the PDF: ' + (e.message || e)); }
}
async function zeAction(a){
  const en = ZE && ZE.cur; $('#zas').hidden = true; if(!en || a === 'close') return;
  if(a === 'preview') return zePreview(en);
  if(a === 'save1') return saveAs(en.blob, baseName(en.path));
  if(a === 'replace'){ ZE.rep = en; return $('#zfr').click(); }
  if(a === 'rename'){ const v = await zprompt('New name. A folder can be part of it, like photos/trip.jpg', en.path); if(v === null) return; const p = cleanPath(v); if(!p) return toast('Type a name first.'); en.path = zeUnique(p, en.id); en.kind = kindOf(en.path); }
  else if(a === 'move'){ const v = await zprompt('Move to folder (leave empty for the top level)', dirName(en.path).replace(/\/$/, '')); if(v === null) return; en.path = zeUnique(cleanPath(cleanPath(v) + '/' + baseName(en.path)), en.id); }
  else if(a === 'rotl' || a === 'rotr') await zeRotate([en], a === 'rotl' ? 270 : 90);
  else if(a === 'del') zeDelete([en]);
  ZE.dirty = true; zeRender();
}
$('#zas').onclick = e => { const a = e.target.dataset.za; if(a) zeAction(a); else if(e.target.id === 'zas') $('#zas').hidden = true; };
$('#zel').onclick = e => {
  const row = e.target.closest('.zi'); if(!row || !ZE) return; const en = ZE.entries.find(x => x.id === +row.dataset.id); if(!en) return;
  if(ZE.sm){ en._s = !en._s; row.classList.toggle('sel', en._s); zeCount(); return; }
  ZE.cur = en; $('#zasn').textContent = en.path; document.querySelectorAll('#zas [data-za="rotl"], #zas [data-za="rotr"]').forEach(b => { b.hidden = en.kind !== 'img'; }); $('#zas').hidden = false;
};
$('#zesb').addEventListener('click', async e => {
  const b = e.target.closest('[data-z]'); if(!b || !ZE) return; const a = b.dataset.z, S = ZE.entries.filter(x => x._s);
  if(a === 'all' || a === 'none'){ const q = ZE.filter.trim().toLowerCase(); ZE.entries.forEach(x => { x._s = a === 'all' && (!q || x.path.toLowerCase().includes(q)); }); return zeRender(); }
  if(!S.length) return toast('Tap the files you want first.');
  if(a === 'ex') return zeSaveZip(S, ZE.name + ' - selection');
  if(a === 'pdf') return zeToPdf(S);
  if(a === 'del') zeDelete(S);
  else if(a === 'mv'){ const v = await zprompt('Move these files to folder (leave empty for the top level)', ''); if(v === null) return; S.forEach(x => { x.path = zeUnique(cleanPath(cleanPath(v) + '/' + baseName(x.path)), x.id); }); }
  else if(a === 'ren'){
    const one = S.length === 1, v = await zprompt(one ? 'New name' : 'Base name. Numbers are added, like photo-001.jpg', one ? S[0].path : 'photo'); if(v === null) return;
    const base = cleanPath(v); if(!base) return toast('Type a name first.');
    if(one) S[0].path = zeUnique(base, S[0].id);
    else zeSorted(S).forEach((x, i) => { x.path = zeUnique(dirName(x.path) + base.replace(/\//g, '_') + '-' + String(i + 1).padStart(3, '0') + (extOf(x.path) ? '.' + extOf(x.path) : ''), x.id); });
    S.forEach(x => { x.kind = kindOf(x.path); });
  }
  ZE.dirty = true; zeRender();
});
$('#zef').oninput = () => { if(ZE){ ZE.filter = $('#zef').value; zeRender(); } };
$('#zesel').onclick = () => { if(!ZE) return; ZE.sm = !ZE.sm; if(!ZE.sm) ZE.entries.forEach(e => { e._s = false; }); zeRender(); };
$('#zesort').onclick = () => { if(!ZE) return; const k = Object.keys(SORTS); ZE.sort = k[(k.indexOf(ZE.sort) + 1) % k.length]; $('#zesort').textContent = 'Sort: ' + SORTS[ZE.sort][0]; zeRender(); };
$('#zeadd').onclick = () => $('#zfa').click();
$('#zezip').onclick = () => $('#zfz').click();
$('#zfa').onchange = async e => {
  const raw = [...e.target.files]; e.target.value = ''; if(!ZE || !raw.length) return; const fs = await snap(raw);
  fs.forEach(f => ZE.entries.push(zeMake(f.name, f, new Date(f.lastModified)))); ZE.dirty = true; zeRender(); if(fs.length) toast(`${fs.length} file${fs.length > 1 ? 's' : ''} added.`);
};
$('#zfz').onchange = async e => {
  const raw = [...e.target.files]; e.target.value = ''; if(!ZE || !raw.length) return;
  try{ for(const f of raw){ const list = await zipEntries(f, (i, n) => toast(`Opening ${f.name}: ${i} of ${n}`)); list.forEach(x => ZE.entries.push(zeMake(x.path, x.blob, x.date))); } ZE.dirty = true; zeRender(); toast('ZIP added.'); }
  catch(x){ toast('Could not add the ZIP: ' + (x.message || x)); }
};
$('#zfr').onchange = async e => {
  const raw = e.target.files[0]; e.target.value = ''; const en = ZE && ZE.rep; if(!raw || !en) return; const [f] = await snap([raw]); if(!f) return;
  if(en.u){ URL.revokeObjectURL(en.u); en.u = null; }
  en.path = zeUnique(en.path.replace(/\.[^./]*$/, '') + (extOf(f.name) ? '.' + extOf(f.name) : ''), en.id);
  en.blob = new Blob([f], {type:MIME[extOf(en.path)] || f.type || 'application/octet-stream'}); en.size = en.blob.size; en.kind = kindOf(en.path); en.date = new Date(f.lastModified);
  ZE.dirty = true; zeRender(); toast('Replaced.');
};
$('#zesave').onclick = () => { if(ZE) zeSaveZip(zeSorted(ZE.entries), ZE.name + ' - edited'); };
$('#zereset').onclick = () => { if(!ZE) return; ZE.entries.forEach(e => { if(e.u) URL.revokeObjectURL(e.u); }); ZE.entries = ZE.orig.map(e => ({...e, u:null, _s:false})); ZE.dirty = false; zeRender(); toast('Back to how the ZIP was when you opened it.'); };
function closeZE(){
  if(ZE) ZE.entries.concat(ZE.orig || []).forEach(e => { if(e.u) URL.revokeObjectURL(e.u); });
  ZE = null; $('#ze').hidden = true; for(const s of ['#zas', '#zid', '#zcd', '#zsd', '#tpd']) $(s).hidden = true;
}
$('#zedone').onclick = () => { if(ZE && ZE.dirty && !ZE.warned){ ZE.warned = true; return toast('You have changes that are not saved. Tap Close again to leave without saving.'); } closeZE(); };
$('#tpx').onclick = () => { $('#tpd').hidden = true; };

/* compress what is inside */
async function zePassOne(en, m){                      // -> {blob, ext?} or null when it would not get smaller
  if(en.kind === 'img'){
    if(extOf(en.path) === 'gif') return null;         // may be animated: leave it alone
    const keepType = /^(jpe?g|png)$/.test(extOf(en.path)), sm = await shrink(en.blob, m);
    if(keepType && sm.bytes.length >= en.size) return null;
    return {blob:new Blob([sm.bytes], {type:'image/jpeg'}), ext:'.jpg'};
  }
  const doc = await PDFDocument.load(await en.blob.arrayBuffer()); await squeeze(doc, m, null); const out = await doc.save();
  return out.length < en.size ? {blob:new Blob([out], {type:'application/pdf'})} : null;
}
const zcList = () => { const S = ZE.entries.filter(x => x._s); return {S, L:(S.length ? S : ZE.entries).filter(x => x.kind === 'img' || x.kind === 'pdf')}; };
$('#zecomp').onclick = () => {
  if(!ZE) return; const {S, L} = zcList(); $('#zcs').textContent = '';
  $('#zcn').textContent = L.length ? `${L.length} file${L.length > 1 ? 's' : ''} will be made smaller${S.length ? ' (the ones you picked)' : ''}. Text in PDFs stays sharp.` : 'There are no pictures or PDFs to compress here.';
  $('#zcd').hidden = false;
};
$('#zcq').onclick = e => { const b = e.target.closest('[data-zq]'); if(!b) return; zq = b.dataset.zq; document.querySelectorAll('#zcq [data-zq]').forEach(x => x.classList.toggle('on', x === b)); };
$('#zcx').onclick = () => { if($('#zcgo').disabled) cancelFlag = true; $('#zcd').hidden = true; };
$('#zcgo').onclick = async () => {
  if(!ZE) return; const {L} = zcList(); if(!L.length) return;
  const tg = (+$('#zct').value || 0) * 1e6, G = {edge:Q[zq].edge, q:Q[zq].q, tune:tg > 0}, before = ZE.entries.reduce((a, x) => a + x.size, 0), btn = $('#zcgo');
  btn.disabled = true; cancelFlag = false;
  try{
    const pass = async tag => {
      const res = new Map();
      for(let i = 0; i < L.length; i++){ if(cancelFlag) throw new Cancelled(); $('#zcs').textContent = `${tag}File ${i + 1} of ${L.length}`; await tick(); const r = await zePassOne(L[i], G); if(r) res.set(L[i].id, r); }
      return res;
    };
    const sizeOf = res => ZE.entries.reduce((a, x) => a + (res.get(x.id) ? res.get(x.id).blob.size : x.size), 0);
    let best;
    if(!tg){ curL = 1; best = await pass(''); }
    else{                                             // find the best quality that fits the size you asked for
      let lo = 0, hi = 1, lv = 1, last, sz; best = null;
      for(let p = 0; p < 6; p++){
        curL = lv; last = await pass(`Pass ${p + 1}: `); sz = sizeOf(last);
        if(sz <= tg){ best = last; if(lv >= 1 || sz >= tg * .92 || hi - lo < .03) break; lo = lv; } else hi = lv;
        lv = p === 0 ? Math.pow(tg / sz, .8) : (lo + hi) / 2;
      }
      if(!best){ curL = 0; best = await pass('Smallest: '); }
    }
    for(const en of ZE.entries){
      const r = best.get(en.id); if(!r) continue; if(en.u){ URL.revokeObjectURL(en.u); en.u = null; }
      en.blob = r.blob; en.size = r.blob.size; if(r.ext) en.path = zeUnique(en.path.replace(/\.[^./]+$/, r.ext), en.id); en.kind = kindOf(en.path);
    }
    const after = ZE.entries.reduce((a, x) => a + x.size, 0); ZE.dirty = true; zeRender();
    $('#zcs').textContent = `Done: ${fmtSize(before)} to ${fmtSize(after)}` + (tg && after > tg ? `. The ${fmtSize(tg)} target could not be reached.` : '.');
  }catch(e){ $('#zcs').textContent = e instanceof Cancelled ? 'Stopped.' : 'Could not compress: ' + (e.message || e); }
  btn.disabled = false;
};

/* split into several ZIPs */
function zeSplitPlan(list, mode, n, name){
  const out = [], pad = k => String(k).padStart(2, '0');
  if(mode === 'n'){ const k = Math.max(1, Math.round(n) || 1); for(let i = 0; i < list.length; i += k) out.push({name:`${name} - part ${pad(out.length + 1)}`, list:list.slice(i, i + k)}); }
  else if(mode === 'mb'){
    const cap = Math.max(.1, n) * 1e6; let cur = [], sz = 0;
    for(const e of list){ if(cur.length && sz + e.size > cap){ out.push({name:`${name} - part ${pad(out.length + 1)}`, list:cur}); cur = []; sz = 0; } cur.push(e); sz += e.size; }
    if(cur.length) out.push({name:`${name} - part ${pad(out.length + 1)}`, list:cur});
  }else{
    const g = new Map(); for(const e of list){ const k = e.path.includes('/') ? e.path.split('/')[0] : 'top level'; if(!g.has(k)) g.set(k, []); g.get(k).push(e); }
    for(const [k, l] of g) out.push({name:`${name} - ${k}`, list:l});
  }
  return out;
}
$('#zesplit').onclick = () => { if(!ZE) return; $('#zsi').textContent = `${ZE.entries.length} files, ${fmtSize(ZE.entries.reduce((a, e) => a + e.size, 0))}. Each part is saved as its own ZIP.`; $('#zss').textContent = ''; $('#zsd').hidden = false; };
$('#zsm').onchange = () => { $('#zsl').hidden = $('#zsm').value === 'folder'; $('#zsv').value = $('#zsm').value === 'mb' ? 25 : 20; };
$('#zsx').onclick = () => { $('#zsd').hidden = true; };
$('#zsgo').onclick = async () => {
  if(!ZE) return; const parts = zeSplitPlan(zeSorted(ZE.entries), $('#zsm').value, +$('#zsv').value, ZE.name);
  if(parts.length < 2) return toast('Nothing to split: everything would stay in one ZIP.');
  if(parts.length > 40) return toast(`That would make ${parts.length} ZIPs. Choose bigger parts (40 at most).`);
  const btn = $('#zsgo'); btn.disabled = true;
  try{
    for(let i = 0; i < parts.length; i++){
      $('#zss').textContent = `Making ${i + 1} of ${parts.length}…`; await tick();
      saveAs(await zeBuildZip(parts[i].list), parts[i].name.replace(/[\\/:*?"<>|]/g, '_') + '.zip'); await new Promise(r => setTimeout(r, 600));
    }
    $('#zss').textContent = `Done. ${parts.length} ZIPs made.`;
  }catch(e){ $('#zss').textContent = 'Could not split: ' + (e.message || e); }
  btn.disabled = false;
};

/* ---------- light / dark mode ---------- */
const colorQuery = window.matchMedia ? matchMedia('(prefers-color-scheme: dark)') : null;
let themePref = 'system';
function themeNow(){ return themePref === 'system' ? (colorQuery && colorQuery.matches ? 'dark' : 'light') : themePref; }
function setTheme(t){
  themePref = t; const now = themeNow(), de = document.documentElement;
  de.setAttribute('data-theme', t === 'system' ? '' : t); de.setAttribute('data-mode', now);
  try{ localStorage.setItem('pm.theme', t); }catch(e){}
  document.querySelectorAll('#tseg [data-th]').forEach(b => b.classList.toggle('on', b.dataset.th === t));
  const m = document.querySelector('meta[name="theme-color"]'); if(m) m.content = now === 'dark' ? '#0f1226' : '#f4f5ff';
  const nb = window.PDFMagicNative; if(nb && nb.setTheme){ try{ nb.setTheme(t); }catch(e){} }
}
{ let t = 'system'; try{ t = localStorage.getItem('pm.theme') || 'system'; }catch(e){} setTheme(t); }
if(colorQuery && colorQuery.addEventListener) colorQuery.addEventListener('change', () => { if(themePref === 'system') setTheme('system'); });
$('#themebtn').onclick = () => { const n = themeNow() === 'dark' ? 'light' : 'dark'; setTheme(n); toast(n === 'dark' ? 'Dark mode on' : 'Light mode on'); };
$('#qual').onchange(); setTask('all');


/* ---------- Android app: native saving, back button, shared files, settings ---------- */
async function nativeSend(blob, name, mode){          // sends the file to the Android side in small pieces, so big PDFs never fill memory
  const id = NA.begin(name, blob.type || 'application/octet-stream', mode), CH = 3 * 256 * 1024;
  for(let o = 0; o < blob.size; o += CH){
    const buf = new Uint8Array(await blob.slice(o, o + CH).arrayBuffer()); let bin = '';
    for(let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
    NA.chunk(id, btoa(bin));
  }
  return NA.end(id);
}
window.nativeBack = () => {                           // closes the top-most screen; returns false when there is nothing to close
  for(const [o, c] of [['#zid', '#zix'], ['#tpd', '#tpx'], ['#zcd', '#zcx'], ['#zsd', '#zsx'], ['#zas', '#zax'], ['#modal', '#close'], ['#tdlg', '#tdno'], ['#zpd', '#zpx'], ['#qd', '#qno'], ['#spd', '#spx'], ['#sheet', ''], ['#pk', '#pkx'], ['#ce', '#cdone'], ['#ed', '#edone'], ['#ze', '#zedone'], ['#mk', '#mkx'], ['#set', '#setx']]){
    const el = $(o); if(el && !el.hidden){ if(c) $(c).click(); else el.hidden = true; return true; }
  }
  return false;
};
async function pullShared(){                          // files sent to PDF Magic from other apps ("Open with" / "Share")
  if(!NA) return; let list = []; try{ list = JSON.parse(NA.takeShared() || '[]'); }catch(e){ return; } if(!list.length) return;
  const files = [];
  for(const it of list){ try{ const b = await (await fetch('__shared__/' + it.id)).blob(); files.push(new File([b], it.name, {type:it.mime, lastModified:Date.now()})); }catch(e){} }
  if(!files.length) return toast('Could not open that file.');
  if(list[0].kind === 'view' && files.every(f => isPdf(f))) setTask('read'); else if(TASKS[$('#task').value].acc !== 'both') setTask('all');
  add(files);
}
window.nativeShared = pullShared;
$('#tseg').onclick = e => { const b = e.target.closest('[data-th]'); if(b) setTheme(b.dataset.th); };
$('#gear').onclick = () => { $('#set').hidden = false; };
$('#setx').onclick = () => { $('#set').hidden = true; };
if(NA){
  try{ const st = JSON.parse(NA.getSettings()); $('#swp').checked = !!st.privacy; $('#swl').checked = !!st.lock; $('#ver').textContent = 'PDF Magic ' + NA.version(); }catch(e){}
  $('#swp').onchange = e => NA.setPrivacy(e.target.checked);
  $('#swl').onchange = e => { if(NA.setLock(e.target.checked) === false){ e.target.checked = false; toast('Set a screen lock (PIN, pattern or fingerprint) in your phone settings first.'); } };
  pullShared();
}else $('#secc').hidden = true;
