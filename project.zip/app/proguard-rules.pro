-keepattributes *Annotation*
-keepclassmembers class com.pdfmagic.app.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
